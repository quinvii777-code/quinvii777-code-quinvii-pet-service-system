-- ============================================================================
-- migration_08_feeding_schedule_fix.sql
-- 修复：喂养订单需要多天服务（feeding_days > 1）时，定金核验锁定排班只锁了第一天，
-- 后台日历也只在预约当天显示，第2/3天不会自动出现，导致商家可能误接其他订单撞期。
-- 现在锁定排班、冲突检测、后台日历视图都会按「喂养天数」正确展开显示每一天。
-- 仅修改函数内的天数计算逻辑，其余行为与原函数完全一致，不影响现有订单数据，
-- 可在已上线项目上直接执行一次。
-- ============================================================================

create or replace function after_order_update()
returns trigger language plpgsql security definer as $$
declare
  i int;
begin
  if new.status is distinct from old.status then
    insert into order_logs (order_id, action)
    values (new.id, format('状态变更：%s → %s', old.status, new.status));
  end if;

  if new.total_fee is distinct from old.total_fee
     or new.transport_fee is distinct from old.transport_fee
     or new.deposit_amount is distinct from old.deposit_amount then
    insert into order_logs (order_id, action)
    values (new.id, format('报价更新：总费用 RM%s / 路费 RM%s / 定金 RM%s',
      coalesce(new.total_fee::text,'-'), coalesce(new.transport_fee::text,'-'), coalesce(new.deposit_amount::text,'-')));
  end if;

  if new.deposit_verified = true and old.deposit_verified = false then
    insert into order_logs (order_id, action) values (new.id, '定金核验到账，排班已锁定');
    delete from schedule_blocks where order_id = new.id;
    for i in 0 .. greatest(
      case when new.service_type = 'feeding_jb' then coalesce(new.feeding_days, 1) else coalesce(new.long_trip_days, 1) end
    , 1) - 1 loop
      insert into schedule_blocks (order_id, block_date) values (new.id, new.service_date + i);
    end loop;
  end if;

  if new.status = 'cancelled' and old.status is distinct from 'cancelled' then
    insert into order_logs (order_id, action)
    values (new.id, format('订单取消：%s 取消，定金处置：%s',
      coalesce(new.cancel_by,'-'), coalesce(new.cancel_deposit_action,'-')));
    if new.cancel_deposit_action = 'refund' and new.deposit_amount is not null then
      insert into finance_transactions (type, category, amount, txn_date, order_id, customer_name, notes)
      values ('refund', '订单退款', new.deposit_amount, current_date, new.id, new.customer_name, '取消订单自动生成退款流水');
    end if;
    delete from schedule_blocks where order_id = new.id;
  end if;

  return new;
end;
$$;

-- ============================================================================
-- 完成。执行后：已有的喂养多日订单如果之前已经核验过定金（排班当时只锁了1天），
-- 建议到后台把该订单「定金核验到账」勾选取消再重新勾选一次，触发排班重新生成，
-- 覆盖完整的服务天数；新提交的喂养多日订单核验定金时会自动正确覆盖所有天数。
-- ============================================================================
