// ============================================================================
// 预约页服务条款 — 从 system_settings（键名 service_terms）读取，后台「价目与条款」可编辑
// 支持中/英/马来三语：优先取当前语言对应的条款正文，没填则回退中文
// 若数据库暂无内容，回退显示默认条款文字，保证页面始终有内容展示
// ============================================================================

function escapeHtmlTerms(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

const DEFAULT_TERMS_TEXT = {
  zh: `提交预约仅作为服务申请，商家审核报价、收到定金并且商家核验转账到账后方锁定档期。页面标价仅参考，最终费用以商家核算为准。客户上传转账截图不代表订单确认。
如宠物本身有慢性病、旧疾，服务期间突发疾病，我方不承担医疗责任。宠物有攻击、咬人史必须提前如实申报，如刻意隐瞒，我方有权终止服务并且定金不予退还。
取消规则：非节假日提前24小时取消，定金可免费改期一次；少于24小时取消，扣除30%服务费；节庆、学校假期定金不予退款，只可改期一次。
上门喂养请屋主自行收好贵重物品，建议家中开启CCTV监控。我方不负责贵重财物遗失纠纷。
接送服务Toll路费、停车费实报实销。
服务期间拍摄宠物照片视频仅用于发送屋主以及纠纷取证，不会对外传播。`,
  en: `Submitting a booking is only a service request. The merchant will review and quote a price; the booking is only locked in once the deposit is verified as received. Prices shown are for reference only — the final fee is subject to the merchant's calculation. Uploading a payment screenshot does not itself confirm the order.
If a pet has a chronic or pre-existing condition, we are not responsible for medical issues that arise during the service. Any history of aggression or biting must be disclosed truthfully in advance; concealment allows us to terminate the service and forfeit the deposit.
Cancellation policy: cancelling more than 24 hours before a non-holiday booking allows one free reschedule of the deposit; cancelling within 24 hours forfeits 30% of the service fee; deposits for holiday or school-break bookings are non-refundable and may only be rescheduled once.
For home feeding, please secure your own valuables and consider enabling CCTV at home — we are not liable for lost valuables.
Toll and parking charges for transport services are charged at actual cost.
Photos/videos taken during service are only used to update the pet owner and for dispute evidence, and will not be shared publicly.`,
  ms: `Menghantar tempahan hanyalah permohonan perkhidmatan. Peniaga akan menyemak dan memberikan sebut harga; tempahan hanya disahkan selepas deposit disahkan diterima. Harga yang dipaparkan hanya sebagai rujukan — bayaran akhir tertakluk kepada pengiraan peniaga. Memuat naik tangkapan skrin pembayaran tidak semestinya mengesahkan tempahan.
Jika haiwan peliharaan mempunyai keadaan kronik atau sedia ada, kami tidak bertanggungjawab ke atas isu perubatan yang timbul semasa perkhidmatan. Sebarang sejarah agresif atau menggigit mesti didedahkan dengan jujur terlebih dahulu; penyembunyian membenarkan kami menamatkan perkhidmatan dan deposit tidak akan dikembalikan.
Polisi pembatalan: pembatalan lebih 24 jam sebelum tempahan bukan cuti membenarkan satu penjadualan semula percuma bagi deposit; pembatalan dalam 24 jam akan kehilangan 30% daripada yuran perkhidmatan; deposit untuk tempahan cuti umum/sekolah tidak akan dikembalikan dan hanya boleh dijadualkan semula sekali.
Untuk perkhidmatan memberi makan di rumah, sila simpan barang berharga anda sendiri dan cadangkan mengaktifkan CCTV di rumah — kami tidak bertanggungjawab ke atas kehilangan barang berharga.
Caj tol dan tempat letak kereta bagi perkhidmatan penghantaran dikenakan mengikut kos sebenar.
Foto/video yang diambil semasa perkhidmatan hanya digunakan untuk mengemas kini pemilik haiwan peliharaan dan sebagai bukti pertikaian, dan tidak akan dikongsi secara terbuka.`
};

function formatTermsBody(text) {
  const lines = String(text).split('\n').map(l => l.trim()).filter(l => l.length > 0);
  return `<ol class="space-y-3 text-sm leading-relaxed text-[var(--color-text)] list-decimal list-inside">${lines.map(l => `<li>${escapeHtmlTerms(l.replace(/^\d+[\.\)、]\s*/, ''))}</li>`).join('')}</ol>`;
}

async function renderTerms(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = '<p class="text-sm text-[var(--color-text-muted)]">加载中…</p>';
  const lang = (typeof getLang === 'function') ? getLang() : 'zh';
  try {
    const { data, error } = await window.sb.from('system_settings').select('value').eq('key', 'service_terms').single();
    if (error) throw error;
    const v = data?.value || {};
    const body = (lang === 'en' && v.body_en) ? v.body_en
      : (lang === 'ms' && v.body_ms) ? v.body_ms
      : (v.body || DEFAULT_TERMS_TEXT[lang] || DEFAULT_TERMS_TEXT.zh);
    el.innerHTML = formatTermsBody(body);
  } catch (e) {
    el.innerHTML = formatTermsBody(DEFAULT_TERMS_TEXT[lang] || DEFAULT_TERMS_TEXT.zh);
  }
}
