// ============================================================================
// 服务价目 — 从数据库 pricing_sections 表读取，后台「价目与条款」可直接编辑
// 首页 index.html 与预约页 booking.html 都调用 renderPricingSections(containerId)
// ============================================================================

// 价目内容支持的简易排版语法（后台编辑价目板块时使用）：
//   ## 标题文字        → 板块内小节标题
//   ### 说明文字       → 更小一级的说明标题
//   标签 | 数值         → 一行价格对照（左标签右数值）
//   * 列表项           → 普通项目符号列表（服务包含项等）
//   - 备注文字          → 小号灰色注意事项
//   空行                → 分段
//   其他               → 普通段落文字

function escapeHtmlPricing(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

function parsePricingBody(text) {
  if (!text) return '';
  const lines = String(text).split('\n');
  let html = '';
  let bulletBuffer = [];
  let noteBuffer = [];

  function flushBullets() {
    if (bulletBuffer.length) {
      html += `<ul class="space-y-1 text-sm md:text-[15px] mb-2 list-disc list-inside">${bulletBuffer.map(b => `<li>${escapeHtmlPricing(b)}</li>`).join('')}</ul>`;
      bulletBuffer = [];
    }
  }
  function flushNotes() {
    if (noteBuffer.length) {
      html += `<ul class="text-xs text-[var(--color-text-muted)] space-y-1 mt-1 mb-2 list-disc list-inside">${noteBuffer.map(n => `<li>${escapeHtmlPricing(n)}</li>`).join('')}</ul>`;
      noteBuffer = [];
    }
  }
  function flushAll() { flushBullets(); flushNotes(); }

  lines.forEach(raw => {
    const line = raw.trim();
    if (line === '') { flushAll(); return; }
    if (line.startsWith('### ')) {
      flushAll();
      html += `<p class="text-sm font-semibold mt-3 mb-1.5 text-[var(--color-text)]">${escapeHtmlPricing(line.slice(4))}</p>`;
    } else if (line.startsWith('## ')) {
      flushAll();
      html += `<p class="font-display font-bold text-base md:text-lg mt-4 mb-2 text-[var(--color-primary)]">${escapeHtmlPricing(line.slice(3))}</p>`;
    } else if (line.startsWith('* ')) {
      flushNotes();
      bulletBuffer.push(line.slice(2));
    } else if (line.startsWith('- ')) {
      flushBullets();
      noteBuffer.push(line.slice(2));
    } else if (line.includes(' | ')) {
      flushAll();
      const idx = line.indexOf(' | ');
      const label = line.slice(0, idx);
      const value = line.slice(idx + 3);
      html += `<div class="flex justify-between gap-3 text-sm md:text-[15px] border-b border-dashed border-[#E4E1D8] py-1.5"><span>${escapeHtmlPricing(label)}</span><span class="font-mono font-semibold text-right">${escapeHtmlPricing(value)}</span></div>`;
    } else {
      flushAll();
      html += `<p class="text-sm text-[var(--color-text-muted)] mb-2 leading-relaxed">${escapeHtmlPricing(line)}</p>`;
    }
  });
  flushAll();
  return html;
}

// 从简易排版正文中提炼一段纯文字摘要（去掉标签符号），用于卡片预览
function extractPricingTeaser(text, maxLen) {
  if (!text) return '';
  const plain = String(text)
    .split('\n')
    .map(l => l.trim())
    .filter(l => l && !l.startsWith('##') && !l.startsWith('###') && !l.includes(' | '))
    .map(l => l.replace(/^[*-]\s*/, ''))
    .join(' ');
  return plain.length > maxLen ? plain.slice(0, maxLen) + '…' : plain;
}

// 首页用：每个已关联服务（service_key）渲染一张带图片的介绍卡片，
// 点击「查看详情」进入独立服务介绍页 service.html，「立即预约」直接带上服务类型进入预约页。
async function renderServiceIntroCards(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = '<p class="text-center text-[var(--color-text-muted)] py-8 col-span-full">加载中…</p>';
  try {
    const { data, error } = await window.sb
      .from('pricing_sections')
      .select('*')
      .eq('is_active', true)
      .not('service_key', 'is', null)
      .order('sort_order', { ascending: true });
    if (error) throw error;

    // 同一个 service_key 只取排序最靠前的一条作为该服务的介绍卡片
    const seen = new Set();
    const cards = (data || []).filter(sec => {
      if (!sec.service_key || seen.has(sec.service_key)) return false;
      seen.add(sec.service_key);
      return true;
    });

    if (cards.length === 0) {
      el.innerHTML = '<p class="text-center text-[var(--color-text-muted)] py-8 col-span-full">服务介绍维护中，请通过 WhatsApp 咨询</p>';
      return;
    }

    el.innerHTML = cards.map(sec => `
      <div class="card overflow-hidden flex flex-col hover:shadow-md transition-shadow">
        <a href="service.html?key=${encodeURIComponent(sec.service_key)}" class="block aspect-[16/10] bg-[var(--color-primary-light)] overflow-hidden">
          ${sec.image_url
            ? `<img src="${escapeHtmlPricing(sec.image_url)}" alt="${escapeHtmlPricing(cardText(sec, 'title'))}" class="w-full h-full object-cover" loading="lazy"
                 onerror="this.onerror=null;this.replaceWith(Object.assign(document.createElement('div'), {className:'w-full h-full flex items-center justify-center text-5xl', textContent:'🐾'}));">`
            : `<div class="w-full h-full flex items-center justify-center text-5xl">🐾</div>`}
        </a>
        <div class="p-4 md:p-5 flex flex-col flex-1">
          <a href="service.html?key=${encodeURIComponent(sec.service_key)}" class="flex items-center flex-wrap gap-2 mb-1.5 hover:opacity-80">
            <h3 class="font-display text-lg md:text-xl font-bold text-[var(--color-primary)]">${escapeHtmlPricing(cardText(sec, 'title'))}</h3>
            ${sec.subtitle ? `<span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-[var(--color-accent)] text-[#3A2705]">${escapeHtmlPricing(cardText(sec, 'subtitle'))}</span>` : ''}
          </a>
          <p class="text-sm text-[var(--color-text-muted)] mb-4 flex-1 leading-relaxed">${escapeHtmlPricing(cardTeaser(sec, 70))}</p>
          <div class="flex gap-2">
            <a href="service.html?key=${encodeURIComponent(sec.service_key)}" class="btn-outline flex-1 text-center text-sm py-2" data-i18n="btnViewDetail">查看详情</a>
            <a href="booking.html?service=${encodeURIComponent(sec.service_key)}" class="btn-accent flex-1 text-center text-sm py-2" data-i18n="navBookNow">立即预约</a>
          </div>
        </div>
      </div>
    `).join('');
    if (typeof applyI18n === 'function') applyI18n();
    return;
  } catch (e) {
    el.innerHTML = '<p class="text-center text-red-600 py-8 col-span-full">服务信息加载失败，请稍后重试</p>';
    console.error(e);
  }
}

// 根据当前语言取 pricing_sections 的标题/副标题：优先取对应语言字段（title_en/title_ms），没有则回退中文
function cardText(sec, field) {
  const lang = (typeof getLang === 'function') ? getLang() : 'zh';
  if (lang === 'en' && sec[field + '_en']) return sec[field + '_en'];
  if (lang === 'ms' && sec[field + '_ms']) return sec[field + '_ms'];
  return sec[field] || '';
}

// 取当前语言对应的「完整价格内容」原始文本：优先取该语言的完整内容，没填就回退中文正文
function bodyForLang(sec) {
  const lang = (typeof getLang === 'function') ? getLang() : 'zh';
  if (lang === 'en' && sec.body_en) return sec.body_en;
  if (lang === 'ms' && sec.body_ms) return sec.body_ms;
  return sec.body || '';
}

// 该语言是否有专属的完整翻译内容（用于判断要不要显示"以下详情仅中文"的提示）
function hasTranslatedBody(sec) {
  const lang = (typeof getLang === 'function') ? getLang() : 'zh';
  if (lang === 'zh') return true;
  return !!(lang === 'en' ? sec.body_en : sec.body_ms);
}

// 卡片摘要：始终从当前语言对应的「完整内容」里截取一小段（跟中文摘要逻辑一致，
// 不会因为管理员填了长文而撑爆卡片版面）
function cardTeaser(sec, maxLen) {
  return extractPricingTeaser(bodyForLang(sec), maxLen);
}

async function renderPricingSections(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = '<p class="text-center text-[var(--color-text-muted)] py-8">加载中…</p>';
  try {
    const { data, error } = await window.sb
      .from('pricing_sections')
      .select('*')
      .eq('is_active', true)
      .order('sort_order', { ascending: true });
    if (error) throw error;
    if (!data || data.length === 0) {
      el.innerHTML = '<p class="text-center text-[var(--color-text-muted)] py-8">价目内容维护中，请通过 WhatsApp 咨询报价</p>';
      return;
    }
    el.innerHTML = `
      <div class="space-y-5">
        ${data.map(sec => `
          <div class="card overflow-hidden">
            ${sec.image_url ? `
              <div class="aspect-[16/9] md:aspect-[21/9] overflow-hidden bg-[var(--color-primary-light)]">
                <img src="${escapeHtmlPricing(sec.image_url)}" alt="${escapeHtmlPricing(cardText(sec, 'title'))}" class="w-full h-full object-cover" loading="lazy"
                     onerror="this.parentElement.style.display='none'">
              </div>` : ''}
            <div class="p-5 md:p-6">
              <div class="flex items-center flex-wrap gap-2 mb-1">
                <h3 class="font-display text-lg md:text-xl font-bold text-[var(--color-primary)]">${escapeHtmlPricing(cardText(sec, 'title'))}</h3>
                ${sec.subtitle ? `<span class="text-xs font-semibold px-2.5 py-1 rounded-full bg-[var(--color-accent)] text-[#3A2705]">${escapeHtmlPricing(cardText(sec, 'subtitle'))}</span>` : ''}
              </div>
              ${!hasTranslatedBody(sec) ? `<p class="text-xs bg-[var(--color-primary-light)] text-[var(--color-primary)] rounded-lg px-3 py-2 mb-2" data-i18n="detailZhOnlyNote">以下详细价目暂时只支持中文，欢迎通过 WhatsApp 用您的语言咨询。</p>` : ''}
              <div class="mt-2">${parsePricingBody(bodyForLang(sec))}</div>
            </div>
          </div>
        `).join('')}
      </div>
      <p class="text-xs text-[var(--color-text-muted)] mt-4 text-center md:text-left">
        * 以上价格仅供参考，最终总价将根据实际情况核算，商家会通过 WhatsApp 另行报价。
      </p>
    `;
    if (typeof applyI18n === 'function') applyI18n();
  } catch (e) {
    el.innerHTML = '<p class="text-center text-red-600 py-8">价目加载失败，请稍后重试</p>';
    console.error(e);
  }
}
