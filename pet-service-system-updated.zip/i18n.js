// ============================================================================
// 简易多语言支持：中文 / English / Bahasa Melayu
// 用法：给需要翻译的元素加 data-i18n="键名"（用 innerHTML 写入，支持内嵌 <span> 等标签），
// 需要翻译 placeholder 的输入框加 data-i18n-placeholder="键名"。
// 注意：后台管理员自己填写的内容（价目文字、服务条款正文、服务名称等）来自数据库，
// 不在本翻译范围内，仍会以管理员填写的语言显示。
// ============================================================================

const I18N_DICT = {
  zh: {
    navHome: '首页 & 商城', navBooking: '预约申请', navOrderQuery: '订单查询', navBookNow: '立即预约', navBookNow2: '立即预约此服务', tabHome: '首页', tabBooking: '预约申请', tabService: '服务介绍', tabOrderQuery: '订单查询',
    navAdminLogin: '管理员登录', navInstall: '📲 安装到桌面',
    footerWa: 'WhatsApp 咨询',
    serviceScopeNotice: '📍 <b>上门喂养</b>仅服务新山地区\u3000｜\u3000🚗 <b>宠物接送</b>仅服务西马区域，东马暂不接单\u3000｜\u3000🐱🐶 仅接收<b>猫、狗</b>预约',
    ourServicesTitle: '我们的服务',
    ourServicesDesc: '点击卡片查看每项服务的详细介绍与完整价目，最终报价商家会通过 WhatsApp 另行确认。',
    shopSectionTitle: '宠物项链展示',
    shopSectionDesc: '精选宠物项链，点击咨询即可通过 WhatsApp 直接下单。',
    noProductsYet: '暂无展品，敬请期待',
    shopWaOrder: 'WhatsApp 咨询下单',
    shopLoadError: '商品加载失败，请稍后重试',
    loadingText: '加载中…',
    btnViewDetail: '查看详情',
    detailZhOnlyNote: '以下详细价目暂时只支持中文，欢迎通过 WhatsApp 用您的语言咨询。',

    pageTitleBooking: '预约申请',
    sectionCustomerInfo: '客户信息',
    labelCustomerName: '客户全名 <span class="text-red-600">*</span>',
    phCustomerName: '请填写真实姓名',
    labelWhatsapp: 'WhatsApp 号码 <span class="text-red-600">*</span>',
    phWhatsapp: '例如：60123456789',

    sectionServiceDetail: '服务详情',
    labelServiceType: '服务类型 <span class="text-red-600">*</span>',
    optChoose: '请选择',
    optFeeding: '上门喂养（仅限新山）',
    optTransport: '宠物接送（仅限西马）',
    labelServiceDate: '服务日期 <span class="text-red-600">*</span>',
    labelTimeSlot: '开始时间 <span class="text-red-600">*</span>',
    labelLongTripDays: '长途行程占用天数',
    phLongTripDays: '仅跨州长途接送需要填写，同城接送填 1',
    hintLongTripDays: '跨州长途接送请填写实际占用天数，方便我们安排档期；市内接送保持默认 1 即可。',
    labelFeedingDays: '需要上门喂养的天数 <span class="text-red-600">*</span>',
    phFeedingDays: '例如出门旅游5天，请填5',
    labelExtraServices: '额外附加服务（可多选，可能产生额外费用）',
    extraWalkDog: '🐕 遛狗', extraWaterPlants: '🪴 浇花', extraParcel: '📦 代拿快递',
    labelAddress: '完整地址 <span class="text-red-600">*</span>',
    phAddress: '请填写详细地址（上门喂养：住址；接送：起点/终点地址）',
    labelExtraNotes: '额外注意事项（选填）',
    phExtraNotes: '例如：猫怕生人、狗需要戴牵引绳、家中有摄像头等其他需要我们注意的事项',

    sectionPetInfo: '宠物信息',
    labelPetSpecies: '宠物类型 <span class="text-red-600">*</span>',
    optCat: '猫', optDog: '狗',
    labelPetCount: '数量 <span class="text-red-600">*</span>',
    labelPetSize: '体型 <span class="text-red-600">*</span>',
    optSizeSmall: '小型犬 ＜10kg', optSizeMedium: '中型犬 10–25kg', optSizeLarge: '大型犬 ＞25kg', optSizeNA: '猫 / 不区分体型',
    labelBiteHistory: '是否有咬人/攻击记录 <span class="text-red-600">*</span>',
    optYes: '是', optNo: '否',
    phBiteNotes: '请如实描述攻击性情况（如实申报，隐瞒将影响定金处理，详见服务条款）',
    labelMedicalHistory: '病史 / 特殊需求 <span class="text-red-600">*</span>',
    phMedicalHistory: '例如：慢性病、长期用药、饮食禁忌等',
    labelEmergencyName: '宠物紧急联系人姓名 <span class="text-red-600">*</span>',
    labelEmergencyPhone: '紧急联系人电话 <span class="text-red-600">*</span>',
    labelVetContact: '就近兽医联系方式 <span class="text-red-600">*</span>',
    labelKeyHandover: '上门钥匙交接方式 <span class="text-red-600">*</span>',
    phKeyHandover: '例如：密码锁/交由邻居/见面交接（接送服务请填「不适用」）',
    labelConsentPhoto: '是否同意拍照录像取证 <span class="text-red-600">*</span>',

    sectionTerms: '服务条款',
    labelAgreeTerms: '我已阅读并同意以上《服务条款》',
    btnSubmit: '提交预约申请', btnSubmitting: '提交中…',
    errAgreeTerms: '请先阅读并勾选同意服务条款。',
    errDailyLimit: '当前预约已满，请改天预约或 WhatsApp 咨询。',
    errNetwork: '网络异常，请稍后重试。',
    successTitle: '预约提交成功！', successSaveHint: '请截图保存以下订单号，用于订单查询与后续跟进。',
    btnCopyOrder: '复制订单号', copiedHint: '已复制！',
    successHint: '商家会尽快通过 WhatsApp 与您联系报价，请留意消息。',
    btnGoOrderQuery: '前往订单查询',
    capacityFullNotice: '当前预约已满，请改天预约或',

    oqTitle: '订单查询',
    oqLabelOrderNumber: '订单号', oqPhOrderNumber: '例如：JB20260101001',
    oqLabelPhone4: 'WhatsApp 手机号后 4 位', oqPhPhone4: '例如：2198',
    oqBtnSearch: '查询订单', oqNotFound: '未找到对应订单，请检查订单号与手机后4位是否正确。',
    oqSvcType: '服务类型', oqSvcDate: '服务日期', oqPet: '宠物', oqSubmittedAt: '提交时间',
    oqFeedingDaysLabel: '喂养天数', oqLongTripDaysLabel: '长途占用天数', oqDaysUnit: '天',
    oqExtraServicesLabel: '额外附加服务', oqExtraNotesLabel: '额外注意事项',
    oqTotalFee: '总费用', oqTransportFee: '路费', oqDepositLabel: '定金',
    oqDepositVerifyLabel: '定金核验', oqFinalVerifyLabel: '尾款核验',
    oqVerifiedReceived: '已到账', oqPendingReview: '待核验', oqVerified: '已核验',
    oqUploadedProofsTitle: '已上传凭证', oqNoUploads: '暂无上传记录',
    oqUploadProofTitle: '上传转账凭证',
    oqUploadWarning: '⚠️ 上传转账凭证仅代表提交截图，不代表商家确认收款，收款需要管理员后台人工核验。',
    oqProofTypeDeposit: '定金凭证', oqProofTypeFinal: '尾款凭证', oqBtnUpload: '上传凭证',
    oqSelectFileFirst: '请先选择要上传的图片。', oqUploading: '上传中…',
    oqUploadSuccess: '凭证已上传，请等待管理员核验。', oqUploadFailed: '上传失败',
    oqOrderMismatch: '订单信息不匹配',
    statusPending: '待审核', statusQuoted: '已报价待定金', statusDepositConfirmed: '定金核验到账排班',
    statusInService: '服务中', statusCompleted: '完成', statusCancelled: '已取消',
  },

  en: {
    navHome: 'Home & Shop', navBooking: 'Book a Service', navOrderQuery: 'Track Order', navBookNow: 'Book Now', navBookNow2: 'Book This Service', tabHome: 'Home', tabBooking: 'Booking', tabService: 'Service Details', tabOrderQuery: 'Track Order',
    navAdminLogin: 'Admin Login', navInstall: '📲 Install App',
    footerWa: 'WhatsApp Us',
    serviceScopeNotice: '📍 <b>In-Home Feeding</b> serves Johor Bahru only\u3000｜\u3000🚗 <b>Pet Transport</b> serves West Malaysia only, East Malaysia not yet available\u3000｜\u3000🐱🐶 <b>Cats & dogs</b> only',
    ourServicesTitle: 'Our Services',
    ourServicesDesc: 'Tap a card for the full details and pricing of each service — final quotes are confirmed by the merchant via WhatsApp.',
    shopSectionTitle: 'Pet Necklace Collection',
    shopSectionDesc: 'Handpicked pet necklaces — tap to order directly via WhatsApp.',
    noProductsYet: 'No items yet, stay tuned',
    shopWaOrder: 'WhatsApp to Order',
    shopLoadError: 'Failed to load products, please try again later',
    loadingText: 'Loading…',
    btnViewDetail: 'View Details',
    detailZhOnlyNote: 'The detailed pricing below is currently only available in Chinese — feel free to WhatsApp us in your preferred language.',

    pageTitleBooking: 'Booking Request',
    sectionCustomerInfo: 'Customer Info',
    labelCustomerName: 'Full Name <span class="text-red-600">*</span>',
    phCustomerName: 'Your real name',
    labelWhatsapp: 'WhatsApp Number <span class="text-red-600">*</span>',
    phWhatsapp: 'e.g. 60123456789',

    sectionServiceDetail: 'Service Details',
    labelServiceType: 'Service Type <span class="text-red-600">*</span>',
    optChoose: 'Please select',
    optFeeding: 'Home Pet Feeding (Johor Bahru only)',
    optTransport: 'Pet Transport (West Malaysia only)',
    labelServiceDate: 'Service Date <span class="text-red-600">*</span>',
    labelTimeSlot: 'Start Time <span class="text-red-600">*</span>',
    labelLongTripDays: 'Long-trip duration (days)',
    phLongTripDays: 'For interstate trips only, keep as 1 for local trips',
    hintLongTripDays: 'For interstate long trips, please enter the actual number of days so we can plan the schedule; keep the default of 1 for local trips.',
    labelFeedingDays: 'Number of feeding days <span class="text-red-600">*</span>',
    phFeedingDays: 'e.g. 5 for a 5-day trip',
    labelExtraServices: 'Add-on services (multiple choice, may incur extra fees)',
    extraWalkDog: '🐕 Dog Walking', extraWaterPlants: '🪴 Plant Watering', extraParcel: '📦 Parcel Collection',
    labelAddress: 'Full Address <span class="text-red-600">*</span>',
    phAddress: 'Detailed address (feeding: home address; transport: pickup/drop-off address)',
    labelExtraNotes: 'Additional Notes (optional)',
    phExtraNotes: 'e.g. cat is shy with strangers, dog needs a leash, there is a CCTV camera at home, etc.',

    sectionPetInfo: 'Pet Info',
    labelPetSpecies: 'Pet Type <span class="text-red-600">*</span>',
    optCat: 'Cat', optDog: 'Dog',
    labelPetCount: 'Quantity <span class="text-red-600">*</span>',
    labelPetSize: 'Size <span class="text-red-600">*</span>',
    optSizeSmall: 'Small dog <10kg', optSizeMedium: 'Medium dog 10–25kg', optSizeLarge: 'Large dog >25kg', optSizeNA: 'Cat / size not applicable',
    labelBiteHistory: 'Any history of biting / aggression? <span class="text-red-600">*</span>',
    optYes: 'Yes', optNo: 'No',
    phBiteNotes: 'Please describe honestly (concealment will affect deposit handling, see terms)',
    labelMedicalHistory: 'Medical history / special needs <span class="text-red-600">*</span>',
    phMedicalHistory: 'e.g. chronic conditions, medication, dietary restrictions',
    labelEmergencyName: 'Emergency Contact Name <span class="text-red-600">*</span>',
    labelEmergencyPhone: 'Emergency Contact Phone <span class="text-red-600">*</span>',
    labelVetContact: 'Nearby Vet Contact <span class="text-red-600">*</span>',
    labelKeyHandover: 'Key Handover Method <span class="text-red-600">*</span>',
    phKeyHandover: 'e.g. keypad lock / via neighbor / meet in person (write "N/A" for transport service)',
    labelConsentPhoto: 'Consent to photo/video documentation? <span class="text-red-600">*</span>',

    sectionTerms: 'Terms of Service',
    labelAgreeTerms: 'I have read and agree to the Terms of Service above',
    btnSubmit: 'Submit Booking Request', btnSubmitting: 'Submitting…',
    errAgreeTerms: 'Please read and agree to the terms of service first.',
    errDailyLimit: 'Fully booked for today, please try another day or WhatsApp us.',
    errNetwork: 'Network error, please try again later.',
    successTitle: 'Booking request submitted!', successSaveHint: 'Please screenshot and save the order number below for tracking and follow-up.',
    btnCopyOrder: 'Copy Order Number', copiedHint: 'Copied!',
    successHint: 'We will contact you via WhatsApp with a quote soon, please keep an eye on your messages.',
    btnGoOrderQuery: 'Go to Order Tracking',
    capacityFullNotice: 'Fully booked today, please try another day or',

    oqTitle: 'Order Tracking',
    oqLabelOrderNumber: 'Order Number', oqPhOrderNumber: 'e.g. JB20260101001',
    oqLabelPhone4: 'Last 4 digits of WhatsApp number', oqPhPhone4: 'e.g. 2198',
    oqBtnSearch: 'Search Order', oqNotFound: 'Order not found, please check the order number and last 4 digits.',
    oqSvcType: 'Service Type', oqSvcDate: 'Service Date', oqPet: 'Pet', oqSubmittedAt: 'Submitted At',
    oqFeedingDaysLabel: 'Feeding Days', oqLongTripDaysLabel: 'Trip Duration', oqDaysUnit: 'day(s)',
    oqExtraServicesLabel: 'Add-on Services', oqExtraNotesLabel: 'Additional Notes',
    oqTotalFee: 'Total Fee', oqTransportFee: 'Transport Fee', oqDepositLabel: 'Deposit',
    oqDepositVerifyLabel: 'Deposit Status', oqFinalVerifyLabel: 'Final Payment Status',
    oqVerifiedReceived: 'Received', oqPendingReview: 'Pending', oqVerified: 'Verified',
    oqUploadedProofsTitle: 'Uploaded Proofs', oqNoUploads: 'No uploads yet',
    oqUploadProofTitle: 'Upload Payment Proof',
    oqUploadWarning: '⚠️ Uploading a proof only submits a screenshot — it does not confirm payment has been received. Confirmation requires manual verification by the admin.',
    oqProofTypeDeposit: 'Deposit Proof', oqProofTypeFinal: 'Final Payment Proof', oqBtnUpload: 'Upload Proof',
    oqSelectFileFirst: 'Please select an image to upload first.', oqUploading: 'Uploading…',
    oqUploadSuccess: 'Proof uploaded, please wait for admin verification.', oqUploadFailed: 'Upload failed',
    oqOrderMismatch: 'Order information does not match',
    statusPending: 'Pending Review', statusQuoted: 'Quoted, Awaiting Deposit', statusDepositConfirmed: 'Deposit Confirmed, Scheduled',
    statusInService: 'In Service', statusCompleted: 'Completed', statusCancelled: 'Cancelled',
  },

  ms: {
    navHome: 'Laman Utama & Kedai', navBooking: 'Buat Tempahan', navOrderQuery: 'Semak Tempahan', navBookNow: 'Tempah Sekarang', navBookNow2: 'Tempah Perkhidmatan Ini', tabHome: 'Laman Utama', tabBooking: 'Tempahan', tabService: 'Butiran Servis', tabOrderQuery: 'Semak Tempahan',
    navAdminLogin: 'Log Masuk Admin', navInstall: '📲 Pasang Aplikasi',
    footerWa: 'Hubungi WhatsApp',
    serviceScopeNotice: '📍 <b>Memberi Makan di Rumah</b> hanya untuk Johor Bahru\u3000｜\u3000🚗 <b>Penghantaran Haiwan</b> hanya untuk Malaysia Barat, Malaysia Timur belum tersedia\u3000｜\u3000🐱🐶 Hanya <b>kucing & anjing</b>',
    ourServicesTitle: 'Perkhidmatan Kami',
    ourServicesDesc: 'Ketik kad untuk butiran penuh dan harga setiap perkhidmatan — sebut harga akhir disahkan oleh peniaga melalui WhatsApp.',
    shopSectionTitle: 'Koleksi Rantai Leher Haiwan',
    shopSectionDesc: 'Rantai leher haiwan pilihan — ketik untuk tempah terus melalui WhatsApp.',
    noProductsYet: 'Belum ada produk, nantikan',
    shopWaOrder: 'Tempah melalui WhatsApp',
    shopLoadError: 'Gagal memuatkan produk, sila cuba lagi',
    loadingText: 'Memuatkan…',
    btnViewDetail: 'Lihat Butiran',
    detailZhOnlyNote: 'Harga terperinci di bawah buat masa ini hanya tersedia dalam Bahasa Cina — sila hubungi kami melalui WhatsApp dalam bahasa pilihan anda.',

    pageTitleBooking: 'Permohonan Tempahan',
    sectionCustomerInfo: 'Maklumat Pelanggan',
    labelCustomerName: 'Nama Penuh <span class="text-red-600">*</span>',
    phCustomerName: 'Nama sebenar anda',
    labelWhatsapp: 'Nombor WhatsApp <span class="text-red-600">*</span>',
    phWhatsapp: 'cth: 60123456789',

    sectionServiceDetail: 'Butiran Perkhidmatan',
    labelServiceType: 'Jenis Perkhidmatan <span class="text-red-600">*</span>',
    optChoose: 'Sila pilih',
    optFeeding: 'Memberi Makan di Rumah (Johor Bahru sahaja)',
    optTransport: 'Penghantaran Haiwan (Malaysia Barat sahaja)',
    labelServiceDate: 'Tarikh Perkhidmatan <span class="text-red-600">*</span>',
    labelTimeSlot: 'Masa Mula <span class="text-red-600">*</span>',
    labelLongTripDays: 'Bilangan hari perjalanan jauh',
    phLongTripDays: 'Hanya untuk perjalanan antara negeri, kekalkan 1 untuk dalam bandar',
    hintLongTripDays: 'Untuk perjalanan jauh antara negeri, sila isi bilangan hari sebenar supaya kami boleh atur jadual; kekalkan 1 untuk penghantaran dalam bandar.',
    labelFeedingDays: 'Bilangan hari perkhidmatan memberi makan <span class="text-red-600">*</span>',
    phFeedingDays: 'cth: isi 5 jika bercuti 5 hari',
    labelExtraServices: 'Perkhidmatan tambahan (boleh pilih lebih dari satu, mungkin dikenakan caj tambahan)',
    extraWalkDog: '🐕 Bawa Anjing Berjalan', extraWaterPlants: '🪴 Siram Pokok', extraParcel: '📦 Ambil Bungkusan',
    labelAddress: 'Alamat Penuh <span class="text-red-600">*</span>',
    phAddress: 'Alamat terperinci (memberi makan: alamat rumah; penghantaran: alamat ambil/hantar)',
    labelExtraNotes: 'Catatan Tambahan (pilihan)',
    phExtraNotes: 'cth: kucing takut orang asing, anjing perlu tali kekang, terdapat CCTV di rumah, dll.',

    sectionPetInfo: 'Maklumat Haiwan Peliharaan',
    labelPetSpecies: 'Jenis Haiwan <span class="text-red-600">*</span>',
    optCat: 'Kucing', optDog: 'Anjing',
    labelPetCount: 'Bilangan <span class="text-red-600">*</span>',
    labelPetSize: 'Saiz <span class="text-red-600">*</span>',
    optSizeSmall: 'Anjing kecil <10kg', optSizeMedium: 'Anjing sederhana 10–25kg', optSizeLarge: 'Anjing besar >25kg', optSizeNA: 'Kucing / saiz tidak berkaitan',
    labelBiteHistory: 'Ada sejarah menggigit / agresif? <span class="text-red-600">*</span>',
    optYes: 'Ya', optNo: 'Tidak',
    phBiteNotes: 'Sila terangkan dengan jujur (penyembunyian akan menjejaskan pengendalian deposit, rujuk terma)',
    labelMedicalHistory: 'Sejarah perubatan / keperluan khas <span class="text-red-600">*</span>',
    phMedicalHistory: 'cth: penyakit kronik, ubat jangka panjang, sekatan pemakanan',
    labelEmergencyName: 'Nama Kenalan Kecemasan <span class="text-red-600">*</span>',
    labelEmergencyPhone: 'Nombor Telefon Kecemasan <span class="text-red-600">*</span>',
    labelVetContact: 'Kenalan Doktor Haiwan Berdekatan <span class="text-red-600">*</span>',
    labelKeyHandover: 'Cara Serahan Kunci <span class="text-red-600">*</span>',
    phKeyHandover: 'cth: kunci kod / melalui jiran / serahan bersemuka (isi "Tidak Berkaitan" untuk perkhidmatan penghantaran)',
    labelConsentPhoto: 'Bersetuju dengan dokumentasi foto/video? <span class="text-red-600">*</span>',

    sectionTerms: 'Terma Perkhidmatan',
    labelAgreeTerms: 'Saya telah membaca dan bersetuju dengan Terma Perkhidmatan di atas',
    btnSubmit: 'Hantar Permohonan Tempahan', btnSubmitting: 'Menghantar…',
    errAgreeTerms: 'Sila baca dan bersetuju dengan terma perkhidmatan dahulu.',
    errDailyLimit: 'Tempahan hari ini sudah penuh, sila cuba hari lain atau hubungi WhatsApp.',
    errNetwork: 'Ralat rangkaian, sila cuba lagi kemudian.',
    successTitle: 'Permohonan tempahan berjaya dihantar!', successSaveHint: 'Sila ambil tangkapan skrin dan simpan nombor tempahan di bawah untuk semakan dan susulan.',
    btnCopyOrder: 'Salin Nombor Tempahan', copiedHint: 'Disalin!',
    successHint: 'Kami akan menghubungi anda melalui WhatsApp dengan sebut harga tidak lama lagi, sila perhatikan mesej anda.',
    btnGoOrderQuery: 'Pergi ke Semakan Tempahan',
    capacityFullNotice: 'Tempahan hari ini penuh, sila cuba hari lain atau',

    oqTitle: 'Semakan Tempahan',
    oqLabelOrderNumber: 'Nombor Tempahan', oqPhOrderNumber: 'cth: JB20260101001',
    oqLabelPhone4: '4 digit terakhir nombor WhatsApp', oqPhPhone4: 'cth: 2198',
    oqBtnSearch: 'Semak Tempahan', oqNotFound: 'Tempahan tidak dijumpai, sila semak nombor tempahan dan 4 digit terakhir.',
    oqSvcType: 'Jenis Perkhidmatan', oqSvcDate: 'Tarikh Perkhidmatan', oqPet: 'Haiwan Peliharaan', oqSubmittedAt: 'Dihantar Pada',
    oqFeedingDaysLabel: 'Hari Memberi Makan', oqLongTripDaysLabel: 'Tempoh Perjalanan', oqDaysUnit: 'hari',
    oqExtraServicesLabel: 'Perkhidmatan Tambahan', oqExtraNotesLabel: 'Catatan Tambahan',
    oqTotalFee: 'Jumlah Bayaran', oqTransportFee: 'Yuran Pengangkutan', oqDepositLabel: 'Deposit',
    oqDepositVerifyLabel: 'Status Deposit', oqFinalVerifyLabel: 'Status Baki',
    oqVerifiedReceived: 'Diterima', oqPendingReview: 'Menunggu', oqVerified: 'Disahkan',
    oqUploadedProofsTitle: 'Bukti Dimuat Naik', oqNoUploads: 'Belum ada muat naik',
    oqUploadProofTitle: 'Muat Naik Bukti Pembayaran',
    oqUploadWarning: '⚠️ Memuat naik bukti hanya menghantar tangkapan skrin — ia tidak mengesahkan pembayaran telah diterima. Pengesahan memerlukan semakan manual oleh admin.',
    oqProofTypeDeposit: 'Bukti Deposit', oqProofTypeFinal: 'Bukti Baki', oqBtnUpload: 'Muat Naik Bukti',
    oqSelectFileFirst: 'Sila pilih imej untuk dimuat naik dahulu.', oqUploading: 'Memuat naik…',
    oqUploadSuccess: 'Bukti dimuat naik, sila tunggu pengesahan admin.', oqUploadFailed: 'Muat naik gagal',
    oqOrderMismatch: 'Maklumat tempahan tidak sepadan',
    statusPending: 'Menunggu Semakan', statusQuoted: 'Disebut Harga, Menunggu Deposit', statusDepositConfirmed: 'Deposit Disahkan, Dijadualkan',
    statusInService: 'Sedang Berkhidmat', statusCompleted: 'Selesai', statusCancelled: 'Dibatalkan',
  }
};

function getLang() {
  return localStorage.getItem('site_lang') || 'zh';
}

function t(key) {
  const lang = getLang();
  return (I18N_DICT[lang] && I18N_DICT[lang][key]) || I18N_DICT.zh[key] || key;
}

function applyI18n() {
  const lang = getLang();
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.innerHTML = t(el.getAttribute('data-i18n'));
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    el.placeholder = t(el.getAttribute('data-i18n-placeholder'));
  });
  document.documentElement.lang = lang === 'zh' ? 'zh-CN' : (lang === 'en' ? 'en' : 'ms');
  document.querySelectorAll('.lang-btn').forEach(b => {
    b.classList.toggle('opacity-100', b.dataset.lang === lang);
    b.classList.toggle('font-bold', b.dataset.lang === lang);
    b.classList.toggle('opacity-60', b.dataset.lang !== lang);
  });
}

function setLang(lang) {
  localStorage.setItem('site_lang', lang);
  applyI18n();
  document.dispatchEvent(new CustomEvent('langchange', { detail: { lang } }));
}

// 渲染语言切换按钮到指定容器（页头调用）
function renderLangSwitcher(containerId) {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = `
    <button type="button" class="lang-btn text-xs px-1.5" data-lang="zh" onclick="setLang('zh')">中</button>
    <span class="opacity-40 text-xs">|</span>
    <button type="button" class="lang-btn text-xs px-1.5" data-lang="en" onclick="setLang('en')">EN</button>
    <span class="opacity-40 text-xs">|</span>
    <button type="button" class="lang-btn text-xs px-1.5" data-lang="ms" onclick="setLang('ms')">BM</button>
  `;
}

document.addEventListener('DOMContentLoaded', applyI18n);
