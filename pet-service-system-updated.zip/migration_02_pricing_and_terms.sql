-- ============================================================================
-- 增量迁移：价目板块表（后台可编辑）+ 服务条款存入 system_settings
-- 可安全在已运行过 schema.sql 的项目上执行，不会影响现有订单/客户等数据
-- ============================================================================

-- 1. 价目板块表
create table if not exists pricing_sections (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subtitle text,                 -- 标题旁的小标签，例如"仅新山地区"
  image_url text,                -- 板块配图外链 URL（可留空）
  body text not null default '', -- 价格内容，支持简易排版语法（见管理后台说明）
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

drop trigger if exists trg_pricing_sections_updated on pricing_sections;
create trigger trg_pricing_sections_updated before update on pricing_sections
  for each row execute function set_updated_at();

alter table pricing_sections enable row level security;

drop policy if exists public_read_active_pricing on pricing_sections;
create policy public_read_active_pricing on pricing_sections for select
  to anon, authenticated using (is_active = true or auth.role() = 'authenticated');

drop policy if exists admin_write_pricing on pricing_sections;
create policy admin_write_pricing on pricing_sections for insert
  to authenticated with check (true);

drop policy if exists admin_update_pricing on pricing_sections;
create policy admin_update_pricing on pricing_sections for update
  to authenticated using (true) with check (true);

drop policy if exists admin_delete_pricing on pricing_sections;
create policy admin_delete_pricing on pricing_sections for delete
  to authenticated using (true);

-- 2. 服务条款默认内容（写入 system_settings，键名 service_terms，后台可编辑）
insert into system_settings (key, value)
values ('service_terms', jsonb_build_object('body',
  '提交预约仅作为服务申请，商家审核报价、收到定金并且商家核验转账到账后方锁定档期。页面标价仅参考，最终费用以商家核算为准。客户上传转账截图不代表订单确认。
如宠物本身有慢性病、旧疾，服务期间突发疾病，我方不承担医疗责任。宠物有攻击、咬人史必须提前如实申报，如刻意隐瞒，我方有权终止服务并且定金不予退还。
取消规则：非节假日提前24小时取消，定金可免费改期一次；少于24小时取消，扣除30%服务费；节庆、学校假期定金不予退款，只可改期一次。
上门喂养请屋主自行收好贵重物品，建议家中开启CCTV监控。我方不负责贵重财物遗失纠纷。
接送服务Toll路费、停车费实报实销。
服务期间拍摄宠物照片视频仅用于发送屋主以及纠纷取证，不会对外传播。'
))
on conflict (key) do nothing;

-- 3. 价目板块初始内容（按最新海报文案；「西马长途接送」暂不上线，如需恢复可在后台新增板块）
insert into pricing_sections (id, title, subtitle, body, sort_order, is_active)
values (
  '11111111-1111-1111-1111-111111111101',
  '新山上门宠物喂养',
  '仅新山地区',
  '毛孩子留在熟悉家中，降低寄养应激

## 单次服务包含
* 喂食
* 更换饮水
* 清理粪便
* 简单宠物区域清洁
* 服务后拍照短视频反馈

## 参考收费
猫咪首只 | RM30
每额外一只猫咪 | +RM5

### 狗狗计费规则（屋内体型最大狗狗为首只原价，其余狗狗收取对应附加费）
小型犬 ＜10kg | RM30（额外增加一只 +RM18）
中型犬 10–25kg | RM38（额外增加一只 +RM23）
大型犬 ＞25kg | RM48（额外增加一只 +RM29）

## 交通费规则
5km以内 | 免费
5–10km | +RM4
10–20km | +RM8
超过20km | 单独报价
- 访客停车费由宠主承担

## 增值服务
喂药护理 | +RM10/次
遛狗 | RM10/只
浇花、代收快递 | 免费

## 长期订单优惠
连续5天 | 享受5%折扣
连续10天 | 享受10%折扣
- 节假日期间折扣失效

## 档期提示
- 学校假期、公共假期建议提前预定，订单需定金预留时间。',
  1, true
)
on conflict (id) do nothing;

insert into pricing_sections (id, title, subtitle, body, sort_order, is_active)
values (
  '11111111-1111-1111-1111-111111111102',
  '新山 Pet Taxi 猫狗专属接送',
  '新山同城10km内・仅接猫狗',
  '服务范围：新山同城10km以内，仅接猫、狗

## 往返套餐（送去 + 30分钟免费等候 + 送回原出发点，美容/就医首选）
＜10kg | RM60
10–25kg | RM70
＞25kg | RM80

## 单程点对点（仅A送到B，送达结束，无免费等候）
＜10kg | RM34
10–25kg | RM42
＞25kg | RM48

### 多宠附加费（往返、单程收费标准一致）
第2只宠物 | +RM20
第3只宠物 | +RM20
第4只宠物 | +RM20
- 一车上限最多4只猫狗
- 两只25kg以上大型犬同行，费用需单独确认

## 主人随车同行
1位主人随车 | +RM15
- 车内座位有限，宠物承载数量将相应减少；2位及以上同行请提前咨询确认能否接单

## 等候规则
- 30分钟免费等候权益仅往返套餐享有
- 单程接送不包含免费等候时长，原地停留即刻计费，每30分钟 +RM10

## 超出10km计费
超出10km部分 | 每公里 +RM1.6
- 高速路费、停车费实报实销',
  2, true
)
on conflict (id) do nothing;

-- 完成。执行完毕后刷新前台页面即可看到新价目内容，后台「价目与条款」可继续编辑。
