-- ============================================================================
-- migration_09_order_query_extra_fields.sql
-- 修复：客户在「订单查询」页查自己的订单时，看不到自己填过的喂养天数、额外附加
-- 服务（遛狗/浇花/代拿快递）、额外注意事项、地址——因为 public_query_order 这个
-- 查询函数当初手动列了返回字段，没把这几个新字段加进去，即使数据库里有数据，
-- 查询结果也不会带出来。现在补上。
-- 仅替换函数逻辑，不影响现有订单数据，可在已上线项目上直接执行一次。
-- ============================================================================

create or replace function public_query_order(p_order_number text, p_phone_last4 text)
returns jsonb language plpgsql security definer as $$
declare
  r orders%rowtype;
  v_proofs jsonb;
begin
  select * into r from orders
    where order_number = upper(trim(p_order_number))
      and whatsapp_last4 = trim(p_phone_last4);

  if not found then
    return null;
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
      'proof_type', pp.proof_type,
      'uploaded_at', pp.uploaded_at,
      'verified', pp.verified
    ) order by pp.uploaded_at desc), '[]'::jsonb)
  into v_proofs
  from payment_proofs pp where pp.order_id = r.id;

  return jsonb_build_object(
    'order_number', r.order_number,
    'status', r.status,
    'service_type', r.service_type,
    'service_date', r.service_date,
    'time_slot', r.time_slot,
    'pet_species', r.pet_species,
    'pet_count', r.pet_count,
    'long_trip_days', r.long_trip_days,
    'feeding_days', r.feeding_days,
    'extra_services', r.extra_services,
    'extra_notes', r.extra_notes,
    'address', r.address,
    'total_fee', r.total_fee,
    'transport_fee', r.transport_fee,
    'deposit_amount', r.deposit_amount,
    'deposit_verified', r.deposit_verified,
    'full_payment_verified', r.full_payment_verified,
    'created_at', r.created_at,
    'proofs', v_proofs
  );
end;
$$;

grant execute on function public_query_order(text, text) to anon, authenticated;

-- ============================================================================
-- 完成。执行后客户在订单查询页能看到自己填写的喂养天数/额外服务/注意事项/地址。
-- ============================================================================
