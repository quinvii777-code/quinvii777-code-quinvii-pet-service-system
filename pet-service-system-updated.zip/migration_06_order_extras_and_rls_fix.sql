-- ============================================================================
-- migration_06_order_extras_and_rls_fix.sql
--
-- 包含两部分：
-- 1. 修复一个权限漏洞：管理员账号（authenticated）之前只能查看/修改/删除订单，
--    唯独不能新建订单——如果客户提交预约时浏览器里同时登录着后台账号（例如同一
--    浏览器另开了一个后台标签页），提交会报错
--    "new row violates row-level security policy for table orders"。
--    现在补上 authenticated 的 INSERT 权限，行为与其他表的"管理员可完全读写"一致。
-- 2. 新增字段：feeding_days（上门喂养天数）、extra_services（客户勾选的额外服务，
--    如遛狗/浇花/代拿快递）、extra_notes（额外注意事项）。
--
-- 仅新增内容，不影响现有订单数据，可在已上线项目上直接执行一次。
-- ============================================================================

-- 1. 修复 RLS：补上管理员的订单新增权限
drop policy if exists authenticated_insert_orders on orders;
create policy authenticated_insert_orders on orders for insert
  to authenticated with check (true);

-- 2. 新增字段
alter table orders add column if not exists feeding_days int;
alter table orders add column if not exists extra_services text[];
alter table orders add column if not exists extra_notes text;

-- 3. 更新插入前处理函数，让新字段自动生效（天数默认1，非喂养订单自动清空这两个字段）
create or replace function before_order_insert()
returns trigger language plpgsql security definer as $$
declare
  v_customer_id uuid;
  v_whatsapp_norm text;
  v_limit int;
  v_count int;
begin
  v_whatsapp_norm := regexp_replace(new.whatsapp, '\D', '', 'g');
  new.whatsapp := v_whatsapp_norm;

  select (value->>'limit')::int into v_limit from system_settings where key = 'daily_order_limit';
  if v_limit is not null then
    select count(*) into v_count from orders where created_at::date = current_date;
    if v_count >= v_limit then
      raise exception 'DAILY_LIMIT_REACHED' using errcode = 'P0001';
    end if;
  end if;

  select id into v_customer_id from customers where whatsapp = v_whatsapp_norm;
  if v_customer_id is null then
    insert into customers (full_name, whatsapp)
    values (new.customer_name, v_whatsapp_norm)
    returning id into v_customer_id;
  else
    update customers set updated_at = now() where id = v_customer_id;
  end if;
  new.customer_id := v_customer_id;

  new.blacklist_flag := exists (
    select 1 from blacklist where whatsapp = v_whatsapp_norm and is_active = true
  );

  if new.order_number is null or new.order_number = '' then
    new.order_number := generate_order_number();
  end if;

  new.status := 'pending';
  new.total_fee := null;
  new.transport_fee := null;
  new.deposit_amount := null;
  new.deposit_paid_date := null;
  new.full_paid_date := null;
  new.deposit_verified := false;
  new.full_payment_verified := false;
  new.internal_notes := null;
  new.cancel_by := null;
  new.cancel_deposit_action := null;
  new.cancelled_at := null;

  if new.long_trip_days is null or new.long_trip_days < 1 then
    new.long_trip_days := 1;
  end if;
  if new.service_type = 'feeding_jb' and (new.feeding_days is null or new.feeding_days < 1) then
    new.feeding_days := 1;
  end if;
  if new.service_type <> 'feeding_jb' then
    new.feeding_days := null;
    new.extra_services := null;
  end if;

  return new;
end;
$$;

-- ============================================================================
-- 完成。执行后：
-- - 后台已登录状态下也能正常提交测试预约（RLS 问题修复）；
-- - 预约页可以提交「上门喂养」的额外服务勾选、天数、额外注意事项，后台订单详情会显示。
-- ============================================================================
