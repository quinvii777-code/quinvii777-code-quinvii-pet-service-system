-- ============================================================================
-- migration_03_site_images_upload.sql
-- 新增「站点图片」存储桶，让后台可以直接上传图片文件（商城展品 / 价目板块配图），
-- 不再需要先把图片传到外部图床再填链接。
-- 仅新增内容，不影响现有订单、客户、价目等数据，可在已上线项目上直接执行一次。
-- ============================================================================

insert into storage.buckets (id, name, public)
values ('site-images', 'site-images', true)
on conflict (id) do nothing;

-- 仅管理员（已登录）可上传站点图片
drop policy if exists admin_upload_site_images on storage.objects;
create policy admin_upload_site_images on storage.objects for insert
  to authenticated
  with check (bucket_id = 'site-images');

-- 公开读取（首页/预约页展示图片，以及后台预览）
drop policy if exists public_read_site_images on storage.objects;
create policy public_read_site_images on storage.objects for select
  to anon, authenticated
  using (bucket_id = 'site-images');

-- 仅管理员可更新/删除站点图片（例如替换展品图）
drop policy if exists admin_update_site_images on storage.objects;
create policy admin_update_site_images on storage.objects for update
  to authenticated
  using (bucket_id = 'site-images');

drop policy if exists admin_delete_site_images on storage.objects;
create policy admin_delete_site_images on storage.objects for delete
  to authenticated
  using (bucket_id = 'site-images');

-- ============================================================================
-- 完成。执行后无需重新部署代码即可生效（前端已内置对应上传逻辑）。
-- ============================================================================
