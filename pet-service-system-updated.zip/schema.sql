-- ============================================================================
-- 宠物上门喂养 / 接送预约系统 — Supabase 数据库建表脚本
-- 适用范围：新山上门喂养、西马宠物接送、宠物项链商城展示
-- 说明：本脚本可在 Supabase SQL Editor 中一次性完整执行
-- 管理员登录采用 Supabase Auth（邮箱+密码），业务表通过 RLS 只允许
-- 已登录（authenticated）身份执行管理操作，公开访客（anon）仅能：
--   1) 提交预约（INSERT orders，字段受触发器强制清洗）
--   2) 查看已上架商城商品
--   3) 通过安全 RPC 函数查询自己的订单 / 上传付款凭证 / 查询当日名额
-- ============================================================================

-- 扩展：生成 UUID / 随机数
create extension if not exists "pgcrypto";

-- ============================================================================
-- 1. 基础表
-- ============================================================================

-- 1.1 客户档案（CRM）
create table if not exists customers (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  whatsapp text not null unique,           -- 已标准化（仅数字，含国家码）
  notes text,                              -- 历史服务备注
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table customers is '客户档案库（CRM），下单自动归档，管理员可编辑补充';

-- 1.2 宠物档案（隶属客户）
create table if not exists pets (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references customers(id) on delete cascade,
  name text,
  species text check (species in ('cat','dog')),
  personality text,       -- 性格特点
  diet text,              -- 饮食习惯
  likes text,             -- 喜好
  fears text,             -- 害怕事物
  taboos text,            -- 禁忌事项
  long_term_notes text,   -- 长期注意事项
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table pets is '客户名下宠物档案，用于老客户复购自动带出资料';

-- 1.3 黑名单
create table if not exists blacklist (
  id uuid primary key default gen_random_uuid(),
  whatsapp text not null,
  customer_name text,
  reason text not null,
  notes text,
  blacklisted_date date not null default current_date,
  is_active boolean not null default true,   -- true=生效中，false=临时解除（保留记录）
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_blacklist_whatsapp on blacklist (whatsapp);

comment on table blacklist is '黑名单，禁用状态保留历史记录用于追溯';

-- 1.4 系统设置（每日接单上限等）
create table if not exists system_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);

-- 1.5 价目板块（后台可编辑的服务价目卡片，支持简易排版语法）
create table if not exists pricing_sections (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subtitle text,
  title_en text,
  subtitle_en text,
  summary_en text,
  title_ms text,
  subtitle_ms text,
  summary_ms text,
  image_url text,
  body text not null default '',
  body_en text,
  body_ms text,
  service_key text,
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into system_settings (key, value)
values ('daily_order_limit', '{"limit": 8}'::jsonb)
on conflict (key) do nothing;

insert into system_settings (key, value)
values ('homepage_hero', jsonb_build_object(
  'title', '毛孩子在家，也能被温柔照顾',
  'subtitle', '上门喂养减少寄养应激，让猫狗留在熟悉的家中安心生活；点对点宠物接送，专人专车安全送达。新山上门喂养・西马宠物接送，猫狗专属服务，让您安心出门、放心托付。',
  'features', jsonb_build_array('✅ 减少寄养应激', '🏠 上门看护更安心', '🚗 点对点专车接送', '📸 全程拍照留证'),
  'image_url', null
))
on conflict (key) do nothing;

insert into system_settings (key, value)
values ('service_terms', jsonb_build_object('body',
  '提交预约仅作为服务申请，商家审核报价、收到定金并且商家核验转账到账后方锁定档期。页面标价仅参考，最终费用以商家核算为准。客户上传转账截图不代表订单确认。
如宠物本身有慢性病、旧疾，服务期间突发疾病，我方不承担医疗责任。宠物有攻击、咬人史必须提前如实申报，如刻意隐瞒，我方有权终止服务并且定金不予退还。
取消规则：非节假日提前24小时取消，定金可免费改期一次；少于24小时取消，扣除30%服务费；节庆、学校假期定金不予退款，只可改期一次。
上门喂养请屋主自行收好贵重物品，建议家中开启CCTV监控。我方不负责贵重财物遗失纠纷。
接送服务Toll路费、停车费实报实销。
服务期间拍摄宠物照片视频仅用于发送屋主以及纠纷取证，不会对外传播。'
))
on conflict (key) do nothing;

insert into pricing_sections (id, title, subtitle, body, service_key, sort_order, is_active)
values (
  '11111111-1111-1111-1111-111111111101',
  '新山上门宠物喂养',
  '仅新山地区',
  '毛孩子留在熟悉家中，降低寄养应激

## 单次服务包含
* 喂食
* 更换饮水
* 清理粪便
* 简单宠物区域清洁
* 服务后拍照短视频反馈

## 参考收费
猫咪首只 | RM30
每额外一只猫咪 | +RM5

### 狗狗计费规则（屋内体型最大狗狗为首只原价，其余狗狗收取对应附加费）
小型犬 ＜10kg | RM30（额外增加一只 +RM18）
中型犬 10–25kg | RM38（额外增加一只 +RM23）
大型犬 ＞25kg | RM48（额外增加一只 +RM29）

## 交通费规则
5km以内 | 免费
5–10km | +RM4
10–20km | +RM8
超过20km | 单独报价
- 访客停车费由宠主承担

## 增值服务
喂药护理 | +RM10/次
遛狗 | RM10/只
浇花、代收快递 | 免费

## 长期订单优惠
连续5天 | 享受5%折扣
连续10天 | 享受10%折扣
- 节假日期间折扣失效

## 档期提示
- 学校假期、公共假期建议提前预定，订单需定金预留时间。',
  'feeding_jb', 1, true
)
on conflict (id) do nothing;

insert into pricing_sections (id, title, subtitle, body, service_key, sort_order, is_active)
values (
  '11111111-1111-1111-1111-111111111102',
  '新山 Pet Taxi 猫狗专属接送',
  '新山同城10km内・仅接猫狗',
  '服务范围：新山同城10km以内，仅接猫、狗

## 往返套餐（送去 + 30分钟免费等候 + 送回原出发点，美容/就医首选）
＜10kg | RM60
10–25kg | RM70
＞25kg | RM80

## 单程点对点（仅A送到B，送达结束，无免费等候）
＜10kg | RM34
10–25kg | RM42
＞25kg | RM48

### 多宠附加费（往返、单程收费标准一致）
第2只宠物 | +RM20
第3只宠物 | +RM20
第4只宠物 | +RM20
- 一车上限最多4只猫狗
- 两只25kg以上大型犬同行，费用需单独确认

## 主人随车同行
1位主人随车 | +RM15
- 车内座位有限，宠物承载数量将相应减少；2位及以上同行请提前咨询确认能否接单

## 等候规则
- 30分钟免费等候权益仅往返套餐享有
- 单程接送不包含免费等候时长，原地停留即刻计费，每30分钟 +RM10

## 超出10km计费
超出10km部分 | 每公里 +RM1.6
- 高速路费、停车费实报实销',
  'transport_west', 2, true
)
on conflict (id) do nothing;

-- 1.6 商城商品（宠物项链展示）
create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  image_url text not null,
  name text not null,
  name_en text,
  name_ms text,
  price numeric(10,2) not null,
  description text,
  description_en text,
  description_ms text,
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 1.6 订单主表
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,

  customer_id uuid references customers(id),
  customer_name text not null,
  whatsapp text not null,
  whatsapp_last4 text generated always as (right(regexp_replace(whatsapp, '\D', '', 'g'), 4)) stored,

  service_type text not null check (service_type in ('feeding_jb','transport_west')),
  service_date date not null,
  time_slot text not null,
  address text not null,

  pet_species text not null check (pet_species in ('cat','dog')),
  pet_count int not null default 1 check (pet_count > 0),
  pet_size text not null,                       -- 小型/中型/大型 或 不适用(猫)

  has_bite_history boolean not null default false,
  bite_notes text,
  medical_history text,                          -- 病史特殊需求

  emergency_contact_name text not null,
  emergency_contact_phone text not null,
  vet_contact text not null,                     -- 就近兽医联系方式

  key_handover_method text not null,             -- 接送选项填 "不适用"
  consent_photo_video boolean not null,          -- 是否同意拍照录像取证
  agreed_terms boolean not null default false,

  long_trip_days int not null default 1,         -- 长途接送占用天数
  feeding_days int,                              -- 上门喂养需要的服务天数
  extra_services text[],                          -- 客户勾选的额外服务（遛狗/浇花/代拿快递等）
  extra_notes text,                              -- 额外注意事项（客户自由填写）

  status text not null default 'pending'
    check (status in ('pending','quoted','deposit_confirmed','in_service','completed','cancelled')),

  total_fee numeric(10,2),
  transport_fee numeric(10,2),
  deposit_amount numeric(10,2),
  deposit_paid_date date,
  full_paid_date date,
  deposit_verified boolean not null default false,
  full_payment_verified boolean not null default false,

  internal_notes text,                            -- 堵车缓冲提醒、钥匙押金等内部备注

  cancel_by text check (cancel_by in ('customer','merchant')),
  cancel_deposit_action text check (cancel_deposit_action in ('refund','reschedule','forfeit')),
  cancelled_at timestamptz,

  blacklist_flag boolean not null default false,   -- 提交时是否命中黑名单

  feeding_checklist jsonb not null default '{
    "notify_owner_arrival": false,
    "checkin_photo": false,
    "feed_water_clean_bowl": false,
    "clean_waste": false,
    "play_medicine_walk": false,
    "check_doors_windows": false,
    "send_photo_video": false,
    "marked_completed": false
  }'::jsonb,

  transport_checklist jsonb not null default '{
    "deposit_confirmed": false,
    "pickup_location_reconfirmed": false,
    "pickup_photo_evidence": false,
    "prepare_pad_leash_muzzle_disinfect": false,
    "long_trip_rest_stops_planned": false,
    "dropoff_photo_signed": false,
    "vehicle_cleaned_after": false,
    "order_archived": false
  }'::jsonb,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_orders_service_date on orders (service_date);
create index if not exists idx_orders_status on orders (status);
create index if not exists idx_orders_order_number on orders (order_number);
create index if not exists idx_orders_whatsapp_last4 on orders (whatsapp_last4);

-- 1.7 付款凭证存档
create table if not exists payment_proofs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  proof_type text not null check (proof_type in ('deposit','full')),
  image_url text not null,
  uploaded_at timestamptz not null default now(),
  verified boolean not null default false,
  verified_at timestamptz
);

create index if not exists idx_payment_proofs_order on payment_proofs (order_id);

-- 1.8 订单操作日志
create table if not exists order_logs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  action text not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_order_logs_order on order_logs (order_id);

-- 1.9 财务收支台账
create table if not exists finance_transactions (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('income','expense','refund')),
  category text not null,          -- 订单收款/饰品售卖/燃油费/耗材/进货/杂费/退款 等
  amount numeric(10,2) not null,
  txn_date date not null default current_date,
  order_id uuid references orders(id) on delete set null,
  customer_name text,
  notes text,
  created_at timestamptz not null default now()
);

create index if not exists idx_finance_txn_date on finance_transactions (txn_date);
create index if not exists idx_finance_txn_type on finance_transactions (type);

-- 1.10 排班占用表（用于日历与防冲突检测，长途多日自动生成多行）
create table if not exists schedule_blocks (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  block_date date not null,
  created_at timestamptz not null default now()
);

create index if not exists idx_schedule_blocks_date on schedule_blocks (block_date);
create index if not exists idx_schedule_blocks_order on schedule_blocks (order_id);

-- ============================================================================
-- 2. 触发器函数
-- ============================================================================

-- 2.1 通用 updated_at 自动更新
create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_customers_updated on customers;
create trigger trg_customers_updated before update on customers
  for each row execute function set_updated_at();

drop trigger if exists trg_pets_updated on pets;
create trigger trg_pets_updated before update on pets
  for each row execute function set_updated_at();

drop trigger if exists trg_blacklist_updated on blacklist;
create trigger trg_blacklist_updated before update on blacklist
  for each row execute function set_updated_at();

drop trigger if exists trg_products_updated on products;
create trigger trg_products_updated before update on products
  for each row execute function set_updated_at();

drop trigger if exists trg_pricing_sections_updated on pricing_sections;
create trigger trg_pricing_sections_updated before update on pricing_sections
  for each row execute function set_updated_at();

drop trigger if exists trg_orders_updated on orders;
create trigger trg_orders_updated before update on orders
  for each row execute function set_updated_at();

-- 2.2 生成唯一订单号：JB + YYMMDD + 4位随机数
create or replace function generate_order_number()
returns text language plpgsql as $$
declare
  candidate text;
  tries int := 0;
begin
  loop
    candidate := 'JB' || to_char(now(), 'YYMMDD') || lpad(floor(random()*10000)::text, 4, '0');
    exit when not exists (select 1 from orders where order_number = candidate);
    tries := tries + 1;
    if tries > 20 then
      candidate := candidate || floor(random()*100)::text;
      exit;
    end if;
  end loop;
  return candidate;
end;
$$;

-- 2.3 订单插入前处理：客户建档、订单号生成、字段强制清洗（防止前台篡改内部字段）、
--     黑名单命中标记、每日接单上限校验
create or replace function before_order_insert()
returns trigger language plpgsql security definer as $$
declare
  v_customer_id uuid;
  v_whatsapp_norm text;
  v_limit int;
  v_count int;
begin
  v_whatsapp_norm := regexp_replace(new.whatsapp, '\D', '', 'g');
  new.whatsapp := v_whatsapp_norm;

  -- 每日接单上限校验（按提交日计算）
  select (value->>'limit')::int into v_limit from system_settings where key = 'daily_order_limit';
  if v_limit is not null then
    select count(*) into v_count from orders where created_at::date = current_date;
    if v_count >= v_limit then
      raise exception 'DAILY_LIMIT_REACHED' using errcode = 'P0001';
    end if;
  end if;

  -- 客户自动建档（存在则复用，不覆盖已存资料，仅更新时间戳）
  select id into v_customer_id from customers where whatsapp = v_whatsapp_norm;
  if v_customer_id is null then
    insert into customers (full_name, whatsapp)
    values (new.customer_name, v_whatsapp_norm)
    returning id into v_customer_id;
  else
    update customers set updated_at = now() where id = v_customer_id;
  end if;
  new.customer_id := v_customer_id;

  -- 黑名单命中标记（仅标记，不阻止提交，交由后台人工判断）
  new.blacklist_flag := exists (
    select 1 from blacklist where whatsapp = v_whatsapp_norm and is_active = true
  );

  -- 订单号
  if new.order_number is null or new.order_number = '' then
    new.order_number := generate_order_number();
  end if;

  -- 强制清洗：前台（anon）不可预设内部字段，一律以后台字段为准
  new.status := 'pending';
  new.total_fee := null;
  new.transport_fee := null;
  new.deposit_amount := null;
  new.deposit_paid_date := null;
  new.full_paid_date := null;
  new.deposit_verified := false;
  new.full_payment_verified := false;
  new.internal_notes := null;
  new.cancel_by := null;
  new.cancel_deposit_action := null;
  new.cancelled_at := null;
  if new.long_trip_days is null or new.long_trip_days < 1 then
    new.long_trip_days := 1;
  end if;
  if new.service_type = 'feeding_jb' and (new.feeding_days is null or new.feeding_days < 1) then
    new.feeding_days := 1;
  end if;
  if new.service_type <> 'feeding_jb' then
    new.feeding_days := null;
    new.extra_services := null;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_before_order_insert on orders;
create trigger trg_before_order_insert before insert on orders
  for each row execute function before_order_insert();

-- 2.4 订单状态变更自动写日志 + 定金核验后生成排班占用 + 取消退款自动记账
create or replace function after_order_update()
returns trigger language plpgsql security definer as $$
declare
  i int;
begin
  if new.status is distinct from old.status then
    insert into order_logs (order_id, action)
    values (new.id, format('状态变更：%s → %s', old.status, new.status));
  end if;

  if new.total_fee is distinct from old.total_fee
     or new.transport_fee is distinct from old.transport_fee
     or new.deposit_amount is distinct from old.deposit_amount then
    insert into order_logs (order_id, action)
    values (new.id, format('报价更新：总费用 RM%s / 路费 RM%s / 定金 RM%s',
      coalesce(new.total_fee::text,'-'), coalesce(new.transport_fee::text,'-'), coalesce(new.deposit_amount::text,'-')));
  end if;

  if new.deposit_verified = true and old.deposit_verified = false then
    insert into order_logs (order_id, action) values (new.id, '定金核验到账，排班已锁定');
    delete from schedule_blocks where order_id = new.id;
    for i in 0 .. greatest(
      case when new.service_type = 'feeding_jb' then coalesce(new.feeding_days, 1) else coalesce(new.long_trip_days, 1) end
    , 1) - 1 loop
      insert into schedule_blocks (order_id, block_date) values (new.id, new.service_date + i);
    end loop;
  end if;

  if new.status = 'cancelled' and old.status is distinct from 'cancelled' then
    insert into order_logs (order_id, action)
    values (new.id, format('订单取消：%s 取消，定金处置：%s',
      coalesce(new.cancel_by,'-'), coalesce(new.cancel_deposit_action,'-')));
    if new.cancel_deposit_action = 'refund' and new.deposit_amount is not null then
      insert into finance_transactions (type, category, amount, txn_date, order_id, customer_name, notes)
      values ('refund', '订单退款', new.deposit_amount, current_date, new.id, new.customer_name, '取消订单自动生成退款流水');
    end if;
    delete from schedule_blocks where order_id = new.id;
  end if;

  return new;
end;
$$;

drop trigger if exists trg_after_order_update on orders;
create trigger trg_after_order_update after update on orders
  for each row execute function after_order_update();

-- ============================================================================
-- 3. 公开安全 RPC 函数（供 anon 访客调用，均为 SECURITY DEFINER，内部严格校验）
-- ============================================================================

-- 3.1 查询当日名额（不暴露任何订单明细）
create or replace function public_check_capacity(p_date date default current_date)
returns jsonb language plpgsql security definer as $$
declare
  v_limit int;
  v_count int;
begin
  select (value->>'limit')::int into v_limit from system_settings where key = 'daily_order_limit';
  select count(*) into v_count from orders where created_at::date = p_date;
  return jsonb_build_object('limit', v_limit, 'count', v_count, 'available', (v_count < coalesce(v_limit, 999999)));
end;
$$;

-- 3.2 客户按订单号 + WhatsApp 后4位查询自己的订单（仅返回客户可见字段）
create or replace function public_query_order(p_order_number text, p_phone_last4 text)
returns jsonb language plpgsql security definer as $$
declare
  r orders%rowtype;
  v_proofs jsonb;
begin
  select * into r from orders
    where order_number = upper(trim(p_order_number))
      and whatsapp_last4 = trim(p_phone_last4);

  if not found then
    return null;
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
      'proof_type', pp.proof_type,
      'uploaded_at', pp.uploaded_at,
      'verified', pp.verified
    ) order by pp.uploaded_at desc), '[]'::jsonb)
  into v_proofs
  from payment_proofs pp where pp.order_id = r.id;

  return jsonb_build_object(
    'order_number', r.order_number,
    'status', r.status,
    'service_type', r.service_type,
    'service_date', r.service_date,
    'time_slot', r.time_slot,
    'pet_species', r.pet_species,
    'pet_count', r.pet_count,
    'long_trip_days', r.long_trip_days,
    'feeding_days', r.feeding_days,
    'extra_services', r.extra_services,
    'extra_notes', r.extra_notes,
    'address', r.address,
    'total_fee', r.total_fee,
    'transport_fee', r.transport_fee,
    'deposit_amount', r.deposit_amount,
    'deposit_verified', r.deposit_verified,
    'full_payment_verified', r.full_payment_verified,
    'created_at', r.created_at,
    'proofs', v_proofs
  );
end;
$$;

-- 3.3 客户上传付款凭证（仅能写入匹配到的自己的订单）
create or replace function public_upload_payment_proof(
  p_order_number text, p_phone_last4 text, p_image_url text, p_proof_type text
) returns boolean language plpgsql security definer as $$
declare
  v_order_id uuid;
begin
  if p_proof_type not in ('deposit','full') then
    raise exception 'INVALID_PROOF_TYPE';
  end if;

  select id into v_order_id from orders
    where order_number = upper(trim(p_order_number))
      and whatsapp_last4 = trim(p_phone_last4);

  if v_order_id is null then
    return false;
  end if;

  insert into payment_proofs (order_id, proof_type, image_url)
  values (v_order_id, p_proof_type, p_image_url);

  insert into order_logs (order_id, action)
  values (v_order_id, format('客户上传付款凭证（%s）— 待管理员人工核验', p_proof_type));

  return true;
end;
$$;

-- 3.4 后台：排班冲突检测（要求已登录）
create or replace function admin_check_schedule_conflict(
  p_start date, p_days int, p_exclude_order_id uuid default null
) returns jsonb language plpgsql security definer as $$
declare
  v_conflicts jsonb;
begin
  if auth.role() <> 'authenticated' then
    raise exception 'NOT_AUTHORIZED';
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
      'order_id', o.id, 'order_number', o.order_number, 'block_date', sb.block_date
    )), '[]'::jsonb)
  into v_conflicts
  from schedule_blocks sb
  join orders o on o.id = sb.order_id
  where sb.block_date between p_start and (p_start + greatest(p_days,1) - 1)
    and (p_exclude_order_id is null or sb.order_id <> p_exclude_order_id);

  return jsonb_build_object('has_conflict', jsonb_array_length(v_conflicts) > 0, 'conflicts', v_conflicts);
end;
$$;

-- ============================================================================
-- 4. 行级安全策略（RLS）
-- ============================================================================

alter table customers enable row level security;
alter table pets enable row level security;
alter table blacklist enable row level security;
alter table system_settings enable row level security;
alter table products enable row level security;
alter table pricing_sections enable row level security;
alter table orders enable row level security;
alter table payment_proofs enable row level security;
alter table order_logs enable row level security;
alter table finance_transactions enable row level security;
alter table schedule_blocks enable row level security;

-- 4.1 customers：仅管理员可读写
drop policy if exists admin_all_customers on customers;
create policy admin_all_customers on customers for all
  to authenticated using (true) with check (true);

-- 4.2 pets：仅管理员可读写
drop policy if exists admin_all_pets on pets;
create policy admin_all_pets on pets for all
  to authenticated using (true) with check (true);

-- 4.3 blacklist：仅管理员可读写
drop policy if exists admin_all_blacklist on blacklist;
create policy admin_all_blacklist on blacklist for all
  to authenticated using (true) with check (true);

-- 4.4 system_settings：所有人可读（前台需读取每日上限），仅管理员可写
drop policy if exists public_read_settings on system_settings;
create policy public_read_settings on system_settings for select
  to anon, authenticated using (true);
drop policy if exists admin_write_settings on system_settings;
create policy admin_write_settings on system_settings for insert
  to authenticated with check (true);
drop policy if exists admin_update_settings on system_settings;
create policy admin_update_settings on system_settings for update
  to authenticated using (true) with check (true);
drop policy if exists admin_delete_settings on system_settings;
create policy admin_delete_settings on system_settings for delete
  to authenticated using (true);

-- 4.5 products：所有人可读上架商品，仅管理员可写
drop policy if exists public_read_active_products on products;
create policy public_read_active_products on products for select
  to anon, authenticated using (is_active = true or auth.role() = 'authenticated');
drop policy if exists admin_write_products on products;
create policy admin_write_products on products for insert
  to authenticated with check (true);
drop policy if exists admin_update_products on products;
create policy admin_update_products on products for update
  to authenticated using (true) with check (true);
drop policy if exists admin_delete_products on products;
create policy admin_delete_products on products for delete
  to authenticated using (true);

-- 4.5b pricing_sections：所有人可读上架板块，仅管理员可写
drop policy if exists public_read_active_pricing on pricing_sections;
create policy public_read_active_pricing on pricing_sections for select
  to anon, authenticated using (is_active = true or auth.role() = 'authenticated');
drop policy if exists admin_write_pricing on pricing_sections;
create policy admin_write_pricing on pricing_sections for insert
  to authenticated with check (true);
drop policy if exists admin_update_pricing on pricing_sections;
create policy admin_update_pricing on pricing_sections for update
  to authenticated using (true) with check (true);
drop policy if exists admin_delete_pricing on pricing_sections;
create policy admin_delete_pricing on pricing_sections for delete
  to authenticated using (true);

-- 4.6 orders：
--   anon 仅可 INSERT（内部字段由触发器强制清洗，见上）；不可直接 SELECT/UPDATE/DELETE
--   authenticated（管理员）可完全读写
drop policy if exists anon_insert_orders on orders;
create policy anon_insert_orders on orders for insert
  to anon with check (true);
drop policy if exists authenticated_insert_orders on orders;
create policy authenticated_insert_orders on orders for insert
  to authenticated with check (true);
drop policy if exists admin_select_orders on orders;
create policy admin_select_orders on orders for select
  to authenticated using (true);
drop policy if exists admin_update_orders on orders;
create policy admin_update_orders on orders for update
  to authenticated using (true) with check (true);
drop policy if exists admin_delete_orders on orders;
create policy admin_delete_orders on orders for delete
  to authenticated using (true);

-- 4.7 payment_proofs：anon 不可直接访问（只能通过 SECURITY DEFINER 的 public_upload_payment_proof 写入）
--     管理员可读写（核验凭证）
drop policy if exists admin_all_payment_proofs on payment_proofs;
create policy admin_all_payment_proofs on payment_proofs for all
  to authenticated using (true) with check (true);

-- 4.8 order_logs：仅管理员可读；写入均通过触发器/RPC 的 SECURITY DEFINER 完成
drop policy if exists admin_select_order_logs on order_logs;
create policy admin_select_order_logs on order_logs for select
  to authenticated using (true);

-- 4.9 finance_transactions：仅管理员可读写
drop policy if exists admin_all_finance on finance_transactions;
create policy admin_all_finance on finance_transactions for all
  to authenticated using (true) with check (true);

-- 4.10 schedule_blocks：仅管理员可读；写入由触发器完成
drop policy if exists admin_select_schedule on schedule_blocks;
create policy admin_select_schedule on schedule_blocks for select
  to authenticated using (true);
drop policy if exists admin_write_schedule on schedule_blocks;
create policy admin_write_schedule on schedule_blocks for insert
  to authenticated with check (true);
drop policy if exists admin_delete_schedule on schedule_blocks;
create policy admin_delete_schedule on schedule_blocks for delete
  to authenticated using (true);

-- ============================================================================
-- 5. RPC 函数执行权限
-- ============================================================================

grant execute on function public_check_capacity(date) to anon, authenticated;
grant execute on function public_query_order(text, text) to anon, authenticated;
grant execute on function public_upload_payment_proof(text, text, text, text) to anon, authenticated;
grant execute on function admin_check_schedule_conflict(date, int, uuid) to authenticated;

-- ============================================================================
-- 6. Storage：付款凭证存储桶（在 SQL Editor 中可直接创建 bucket 与策略）
-- ============================================================================

insert into storage.buckets (id, name, public)
values ('payment-proofs', 'payment-proofs', true)
on conflict (id) do nothing;

-- 允许任何人（含访客）上传凭证文件到该桶（仅新增，不可读取列表/覆盖他人文件）
drop policy if exists anon_upload_payment_proofs on storage.objects;
create policy anon_upload_payment_proofs on storage.objects for insert
  to anon, authenticated
  with check (bucket_id = 'payment-proofs');

-- 公开读取（用于后台预览凭证图片，及生成的公开 URL）
drop policy if exists public_read_payment_proofs on storage.objects;
create policy public_read_payment_proofs on storage.objects for select
  to anon, authenticated
  using (bucket_id = 'payment-proofs');

-- 仅管理员可删除凭证文件
drop policy if exists admin_delete_payment_proofs on storage.objects;
create policy admin_delete_payment_proofs on storage.objects for delete
  to authenticated
  using (bucket_id = 'payment-proofs');

-- ============================================================================
-- 7. Storage：站点图片存储桶（商城展品图 / 价目板块配图，管理员后台直传）
-- ============================================================================

insert into storage.buckets (id, name, public)
values ('site-images', 'site-images', true)
on conflict (id) do nothing;

-- 仅管理员（已登录）可上传站点图片
drop policy if exists admin_upload_site_images on storage.objects;
create policy admin_upload_site_images on storage.objects for insert
  to authenticated
  with check (bucket_id = 'site-images');

-- 公开读取（首页/预约页展示图片，以及后台预览）
drop policy if exists public_read_site_images on storage.objects;
create policy public_read_site_images on storage.objects for select
  to anon, authenticated
  using (bucket_id = 'site-images');

-- 仅管理员可更新/删除站点图片（例如替换展品图）
drop policy if exists admin_update_site_images on storage.objects;
create policy admin_update_site_images on storage.objects for update
  to authenticated
  using (bucket_id = 'site-images');

drop policy if exists admin_delete_site_images on storage.objects;
create policy admin_delete_site_images on storage.objects for delete
  to authenticated
  using (bucket_id = 'site-images');

-- ============================================================================
-- 8. 实时订阅：让后台能在有新订单时即时收到通知（无需外部服务）
-- ============================================================================
alter publication supabase_realtime add table orders;

-- ============================================================================
-- 完成。执行完毕后请到 Authentication 手动创建唯一管理员账号（见部署文档）。
-- ============================================================================
