// ============================================================================
// Service Worker — 仅缓存本站静态资源（HTML/CSS/JS/图标），
// 不拦截、不缓存 Supabase 等跨域请求，业务数据始终走网络实时读取。
// 更新版本号（CACHE_NAME）即可让访客/管理员自动获取最新静态文件。
// ============================================================================

const CACHE_NAME = "jb-pet-service-shell-v2";

const CORE_ASSETS = [
  "./index.html",
  "./booking.html",
  "./order-query.html",
  "./admin-login.html",
  "./admin-dashboard.html",
  "./styles.css",
  "./supabase-config.js",
  "./pricing.js",
  "./terms.js",
  "./admin-dashboard.js",
  "./manifest.json",
  "./admin-manifest.json",
  "./icon-192.png",
  "./icon-512.png",
  "./apple-touch-icon.png"
];

self.addEventListener("install", (event) => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(CORE_ASSETS)).catch(() => {})
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;

  // 只处理 GET 请求，且只处理本站同源请求；
  // Supabase API / Storage / 字体&CDN 等跨域请求一律直接放行，不做任何缓存干预。
  if (req.method !== "GET" || new URL(req.url).origin !== self.location.origin) {
    return;
  }

  // 页面导航：网络优先，离线时回退缓存（保证在线时始终看到最新页面）
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).then((res) => {
        const resClone = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
        return res;
      }).catch(() => caches.match(req).then((res) => res || caches.match("./index.html")))
    );
    return;
  }

  // 其他静态资源（JS/CSS等）：网络优先，成功则更新缓存并返回最新内容；
  // 离线或请求失败时才回退到缓存，确保每次更新代码后在线用户都能立刻用上最新版本，
  // 不会出现「代码明明部署了、浏览器却还在用旧版 JS」的情况。
  event.respondWith(
    fetch(req).then((res) => {
      const resClone = res.clone();
      caches.open(CACHE_NAME).then((cache) => cache.put(req, resClone));
      return res;
    }).catch(() => caches.match(req))
  );
});
