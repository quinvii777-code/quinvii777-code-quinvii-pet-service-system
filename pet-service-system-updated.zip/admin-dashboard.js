// ============================================================================
// 管理员后台逻辑（原生 JS，无构建）
// ============================================================================

const SERVICE_TYPE_LABEL = { feeding_jb: '上门喂养（新山）', transport_west: '宠物接送（西马）' };
const SPECIES_LABEL = { cat: '猫', dog: '狗' };
const CANCEL_BY_LABEL = { customer: '客户取消', merchant: '商家取消' };
const CANCEL_ACTION_LABEL = { refund: '退款', reschedule: '改期', forfeit: '不予退还' };

const FEEDING_CHECKLIST_LABELS = {
  notify_owner_arrival: 'WhatsApp 提前通知屋主抵达时间',
  checkin_photo: '进门打卡拍照',
  feed_water_clean_bowl: '添粮、换水、清洗食盆',
  clean_waste: '铲屎清理排泄物',
  play_medicine_walk: '陪玩 / 喂药 / 遛狗（如有附加需求）',
  check_doors_windows: '出门检查门窗水电',
  send_photo_video: '照片视频发送屋主',
  marked_completed: '订单标记完成'
};
const TRANSPORT_CHECKLIST_LABELS = {
  deposit_confirmed: '确认定金已经到账',
  pickup_location_reconfirmed: '接送地点二次和客户确认',
  pickup_photo_evidence: '接宠前拍照存档留证',
  prepare_pad_leash_muzzle_disinfect: '备好尿垫、牵引绳、嘴套，出车前车辆消毒',
  long_trip_rest_stops_planned: '长途行程提前规划中途休息站点',
  dropoff_photo_signed: '送达目的地拍照签收',
  vehicle_cleaned_after: '返程完成车内清洁消毒',
  order_archived: '订单完结归档'
};

let currentPanel = 'orders';

// ---------------------------------------------------------------------------
// 认证守卫
// ---------------------------------------------------------------------------
(async function initAuth() {
  const { data: { session } } = await window.sb.auth.getSession();
  if (!session) { window.location.href = 'admin-login.html'; return; }
  document.getElementById('adminEmailLabel').textContent = session.user.email;
  initNav();
  loadPanel('orders');
  initOrderNotifications();
})();

// ---------------------------------------------------------------------------
// 新订单实时提醒：后台页面开着时，一有新订单提交就响铃 + 弹通知，无需外部服务
// ---------------------------------------------------------------------------
const originalDocTitle = document.title;
let unreadOrderCount = 0;

function initOrderNotifications() {
  const bellBtn = document.getElementById('notifBellBtn');
  updateBellIcon();

  bellBtn.addEventListener('click', async () => {
    if (!('Notification' in window)) {
      toast('当前浏览器不支持弹窗通知，仅会响铃提醒', true);
      return;
    }
    if (Notification.permission === 'granted') {
      toast('通知已开启');
      return;
    }
    const perm = await Notification.requestPermission();
    updateBellIcon();
    toast(perm === 'granted' ? '通知已开启，新订单会响铃 + 弹窗提醒' : '未授权通知权限，仍会在页面内响铃提醒');
  });

  // 订阅 orders 表的新增事件（实时）
  window.sb.channel('orders-insert-notify')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'orders' }, (payload) => {
      handleNewOrderNotification(payload.new);
    })
    .subscribe();

  // 点击「订单管理」时清空未读提醒
  document.querySelectorAll('.nav-item[data-panel="orders"]').forEach(btn => {
    btn.addEventListener('click', clearUnreadOrderBadge);
  });
}

function updateBellIcon() {
  const bellBtn = document.getElementById('notifBellBtn');
  const granted = ('Notification' in window) && Notification.permission === 'granted';
  bellBtn.textContent = granted ? '🔔' : '🔕';
  bellBtn.title = granted ? '新订单提醒已开启' : '点击开启新订单提醒';
}

function handleNewOrderNotification(o) {
  playNotificationBeep();

  if ('Notification' in window && Notification.permission === 'granted') {
    const n = new Notification('📋 有新预约订单', {
      body: `${o.customer_name} · ${SERVICE_TYPE_LABEL[o.service_type] || o.service_type} · ${o.service_date}`,
      icon: 'icon-192.png',
      tag: 'new-order-' + o.id
    });
    n.onclick = () => { window.focus(); openOrderDetail(o.id, () => loadPanel('orders')); };
  }

  toast(`📋 新订单：${o.customer_name}（${o.order_number}）`);

  unreadOrderCount++;
  document.getElementById('ordersBadge').classList.remove('hidden');
  document.title = `(${unreadOrderCount}) 新订单！ · ${originalDocTitle}`;

  if (currentPanel === 'orders' && !document.getElementById('modalRoot').innerHTML.trim()) {
    loadPanel('orders');
  }
}

function clearUnreadOrderBadge() {
  unreadOrderCount = 0;
  document.getElementById('ordersBadge').classList.add('hidden');
  document.title = originalDocTitle;
}

function playNotificationBeep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    [0, 0.18].forEach((delay, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = i === 0 ? 880 : 1175;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + delay);
      gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + delay + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + delay + 0.25);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + delay);
      osc.stop(ctx.currentTime + delay + 0.26);
    });
  } catch (e) { /* 浏览器不支持音频播放时静默忽略，仍会有弹窗/toast提醒 */ }
}

window.sb.auth.onAuthStateChange((event) => {
  if (event === 'SIGNED_OUT') window.location.href = 'admin-login.html';
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
  await window.sb.auth.signOut();
  window.location.href = 'admin-login.html';
});

// ---------------------------------------------------------------------------
// 侧边栏导航（横屏常驻 / 竖屏抽屉）
// ---------------------------------------------------------------------------
function initNav() {
  document.querySelectorAll('.nav-item[data-panel]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-item[data-panel]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      loadPanel(btn.dataset.panel);
      closeSidebar();
    });
  });
  document.getElementById('hamburgerBtn').addEventListener('click', () => {
    document.getElementById('sidebar').classList.add('open');
    document.getElementById('overlay').classList.add('open');
  });
  document.getElementById('overlay').addEventListener('click', closeSidebar);
  document.getElementById('settingsBtn').addEventListener('click', openSettingsModal);
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('overlay').classList.remove('open');
}

const PANEL_TITLES = {
  orders: '订单管理', calendar: '排班日历', customers: '客户档案库',
  blacklist: '黑名单管理', finance: '财务收支台账', products: '商城商品管理',
  pricing: '价目与条款'
};

function loadPanel(name) {
  currentPanel = name;
  document.getElementById('panelTitle').textContent = PANEL_TITLES[name];
  const map = { orders: renderOrdersPanel, calendar: renderCalendarPanel, customers: renderCustomersPanel,
    blacklist: renderBlacklistPanel, finance: renderFinancePanel, products: renderProductsPanel,
    pricing: renderPricingPanel };
  map[name]();
}

// ---------------------------------------------------------------------------
// 通用工具
// ---------------------------------------------------------------------------
function escapeHtml(s) {
  if (s === null || s === undefined) return '';
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}
function openModal(html, opts = {}) {
  const root = document.getElementById('modalRoot');
  root.innerHTML = `
    <div class="fixed inset-0 z-50 flex items-start md:items-center justify-center p-0 md:p-4 bg-black/40" id="modalOverlay">
      <div class="bg-white w-full ${opts.wide ? 'md:max-w-3xl' : 'md:max-w-lg'} md:rounded-2xl h-full md:h-auto md:max-h-[90vh] overflow-y-auto form-scroll-pad">
        <div class="sticky top-0 bg-white border-b px-4 md:px-6 py-4 flex items-center justify-between z-10">
          <h3 class="font-display font-bold text-lg">${opts.title || ''}</h3>
          <button id="modalCloseBtn" class="w-8 h-8 rounded-full hover:bg-gray-100 text-lg">✕</button>
        </div>
        <div class="p-4 md:p-6">${html}</div>
      </div>
    </div>
  `;
  document.getElementById('modalCloseBtn').addEventListener('click', closeModal);
  document.getElementById('modalOverlay').addEventListener('click', (e) => { if (e.target.id === 'modalOverlay') closeModal(); });
}
function closeModal() { document.getElementById('modalRoot').innerHTML = ''; }

// 上传图片文件到 site-images 存储桶，返回公开访问 URL
async function uploadSiteImage(file, folder) {
  const ext = (file.name.split('.').pop() || 'jpg').toLowerCase();
  const path = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error: upErr } = await window.sb.storage.from('site-images').upload(path, file, { upsert: false });
  if (upErr) throw upErr;
  const { data: pub } = window.sb.storage.from('site-images').getPublicUrl(path);
  return pub.publicUrl;
}

// 生成「上传图片 / 或填写外链」的通用控件；folder 用于区分存储子目录，urlInputId 是保存最终 URL 的隐藏文本框 id
function imageUploadFieldHtml(fieldId, currentUrl, label) {
  return `
    <div>
      <label class="text-xs text-[var(--color-text-muted)]">${label}</label>
      <div class="flex items-start gap-3">
        <img id="${fieldId}Preview" src="${currentUrl ? escapeHtml(currentUrl) : ''}" class="w-16 h-16 rounded-lg object-cover border flex-shrink-0 ${currentUrl ? '' : 'hidden'}" onerror="this.classList.add('hidden')">
        <div class="flex-1 min-w-0 space-y-1.5">
          <input id="${fieldId}File" type="file" accept="image/*" class="w-full border rounded-lg px-3 py-2 text-sm bg-white">
          <p id="${fieldId}Status" class="text-xs text-[var(--color-text-muted)]"></p>
          <details>
            <summary class="text-xs text-[var(--color-primary)] cursor-pointer">或直接填写图片外链 URL</summary>
            <input id="${fieldId}" class="w-full border rounded-lg px-3 py-2 mt-1 text-sm" value="${escapeHtml(currentUrl || '')}" placeholder="https://...">
          </details>
        </div>
      </div>
    </div>
  `;
}

// 绑定上传控件的文件选择事件：选中文件后自动上传，成功后写入 URL 输入框并刷新预览
function bindImageUploadField(fieldId, folder) {
  const fileInput = document.getElementById(`${fieldId}File`);
  const urlInput = document.getElementById(fieldId);
  const preview = document.getElementById(`${fieldId}Preview`);
  const status = document.getElementById(`${fieldId}Status`);
  fileInput.addEventListener('change', async () => {
    const file = fileInput.files && fileInput.files[0];
    if (!file) return;
    status.textContent = '上传中…';
    status.className = 'text-xs text-[var(--color-text-muted)]';
    try {
      const url = await uploadSiteImage(file, folder);
      urlInput.value = url;
      preview.src = url;
      preview.classList.remove('hidden');
      status.textContent = '✅ 上传成功';
      status.className = 'text-xs text-[var(--color-success)]';
    } catch (e) {
      status.textContent = '上传失败：' + (e.message || '请重试');
      status.className = 'text-xs text-red-600';
    }
  });
}

function toast(msg, isError) {
  const t = document.createElement('div');
  t.textContent = msg;
  t.className = `fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] px-4 py-2.5 rounded-lg text-sm text-white shadow-lg ${isError ? 'bg-red-600' : 'bg-[var(--color-primary)]'}`;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2600);
}

// ---------------------------------------------------------------------------
// 系统设置弹窗
// ---------------------------------------------------------------------------
async function openSettingsModal() {
  const { data } = await window.sb.from('system_settings').select('*').eq('key', 'daily_order_limit').single();
  const limit = data?.value?.limit ?? 8;
  const { data: heroRow } = await window.sb.from('system_settings').select('value').eq('key', 'homepage_hero').single();
  const hero = heroRow?.value || {};
  const features = Array.isArray(hero.features) && hero.features.length === 4
    ? hero.features
    : ['✅ 减少寄养应激', '🏠 上门看护更安心', '🚗 点对点专车接送', '📸 全程拍照留证'];

  const featuresEn = Array.isArray(hero.features_en) && hero.features_en.length === 4 ? hero.features_en : ['', '', '', ''];
  const featuresMs = Array.isArray(hero.features_ms) && hero.features_ms.length === 4 ? hero.features_ms : ['', '', '', ''];

  openModal(`
    <div class="space-y-4">
      <div>
        <label class="block text-sm font-semibold mb-1">每日接单上限</label>
        <input id="dailyLimitInput" type="number" min="1" value="${limit}" class="w-full border rounded-lg px-3 py-2.5">
        <p class="text-xs text-[var(--color-text-muted)] mt-1">前台预约提交达到当日上限后，预约表单会自动关闭并提示改天预约。</p>
      </div>

      <div class="border-t pt-4">
        <h4 class="text-sm font-semibold mb-2">首页顶部大标题区域（中文，默认显示）</h4>
        <div class="space-y-3">
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">大标题</label>
            <input id="heroTitleInput" class="w-full border rounded-lg px-3 py-2" value="${escapeHtml(hero.title || '')}" placeholder="毛孩子在家，也能被温柔照顾">
          </div>
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">副标题说明文字</label>
            <textarea id="heroSubtitleInput" class="w-full border rounded-lg px-3 py-2 min-h-[80px]" placeholder="上门喂养减少寄养应激…">${escapeHtml(hero.subtitle || '')}</textarea>
          </div>
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">4 个卖点小标签</label>
            <div class="grid grid-cols-2 gap-2 mt-1">
              <input id="heroFeature0" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(features[0] || '')}">
              <input id="heroFeature1" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(features[1] || '')}">
              <input id="heroFeature2" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(features[2] || '')}">
              <input id="heroFeature3" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(features[3] || '')}">
            </div>
          </div>
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">背景图片（可选）</label>
            ${imageUploadFieldHtml('heroBannerImage', hero.image_url || '', '')}
            <p class="text-xs text-[var(--color-text-muted)] mt-1">上传后会作为标题区域的背景图（会自动叠加半透明深色，保证文字清晰），不设置则维持纯色背景。</p>
          </div>
        </div>
      </div>

      <details class="border-t pt-4">
        <summary class="text-sm font-semibold cursor-pointer">🌐 English 版本（选填，切到 EN 时显示；不填则显示中文）</summary>
        <div class="space-y-3 mt-3">
          <input id="heroTitleEn" class="w-full border rounded-lg px-3 py-2" value="${escapeHtml(hero.title_en || '')}" placeholder="Title in English">
          <textarea id="heroSubtitleEn" class="w-full border rounded-lg px-3 py-2 min-h-[70px]" placeholder="Subtitle in English">${escapeHtml(hero.subtitle_en || '')}</textarea>
          <div class="grid grid-cols-2 gap-2">
            <input id="heroFeature0En" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(featuresEn[0] || '')}" placeholder="Highlight 1">
            <input id="heroFeature1En" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(featuresEn[1] || '')}" placeholder="Highlight 2">
            <input id="heroFeature2En" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(featuresEn[2] || '')}" placeholder="Highlight 3">
            <input id="heroFeature3En" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(featuresEn[3] || '')}" placeholder="Highlight 4">
          </div>
        </div>
      </details>

      <details class="border-t pt-4">
        <summary class="text-sm font-semibold cursor-pointer">🌐 Bahasa Melayu 版本（选填，切到 BM 时显示；不填则显示中文）</summary>
        <div class="space-y-3 mt-3">
          <input id="heroTitleMs" class="w-full border rounded-lg px-3 py-2" value="${escapeHtml(hero.title_ms || '')}" placeholder="Tajuk dalam Bahasa Melayu">
          <textarea id="heroSubtitleMs" class="w-full border rounded-lg px-3 py-2 min-h-[70px]" placeholder="Sari kata dalam Bahasa Melayu">${escapeHtml(hero.subtitle_ms || '')}</textarea>
          <div class="grid grid-cols-2 gap-2">
            <input id="heroFeature0Ms" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(featuresMs[0] || '')}" placeholder="Ciri 1">
            <input id="heroFeature1Ms" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(featuresMs[1] || '')}" placeholder="Ciri 2">
            <input id="heroFeature2Ms" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(featuresMs[2] || '')}" placeholder="Ciri 3">
            <input id="heroFeature3Ms" class="border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(featuresMs[3] || '')}" placeholder="Ciri 4">
          </div>
        </div>
      </details>

      <button id="saveSettingsBtn" class="btn-primary w-full py-2.5">保存设置</button>
    </div>
  `, { title: '系统设置', wide: true });
  bindImageUploadField('heroBannerImage', 'branding');

  document.getElementById('saveSettingsBtn').addEventListener('click', async () => {
    const val = parseInt(document.getElementById('dailyLimitInput').value, 10) || 1;
    const { error } = await window.sb.from('system_settings')
      .update({ value: { limit: val } }).eq('key', 'daily_order_limit');
    if (error) { toast('保存失败：' + error.message, true); return; }

    const heroPayload = {
      title: document.getElementById('heroTitleInput').value.trim() || null,
      subtitle: document.getElementById('heroSubtitleInput').value.trim() || null,
      features: [
        document.getElementById('heroFeature0').value.trim(),
        document.getElementById('heroFeature1').value.trim(),
        document.getElementById('heroFeature2').value.trim(),
        document.getElementById('heroFeature3').value.trim()
      ],
      image_url: document.getElementById('heroBannerImage').value.trim() || null,
      title_en: document.getElementById('heroTitleEn').value.trim() || null,
      subtitle_en: document.getElementById('heroSubtitleEn').value.trim() || null,
      features_en: [
        document.getElementById('heroFeature0En').value.trim(),
        document.getElementById('heroFeature1En').value.trim(),
        document.getElementById('heroFeature2En').value.trim(),
        document.getElementById('heroFeature3En').value.trim()
      ],
      title_ms: document.getElementById('heroTitleMs').value.trim() || null,
      subtitle_ms: document.getElementById('heroSubtitleMs').value.trim() || null,
      features_ms: [
        document.getElementById('heroFeature0Ms').value.trim(),
        document.getElementById('heroFeature1Ms').value.trim(),
        document.getElementById('heroFeature2Ms').value.trim(),
        document.getElementById('heroFeature3Ms').value.trim()
      ]
    };
    const { data: existingHero } = await window.sb.from('system_settings').select('key').eq('key', 'homepage_hero').single();
    const heroQ = existingHero
      ? window.sb.from('system_settings').update({ value: heroPayload }).eq('key', 'homepage_hero')
      : window.sb.from('system_settings').insert({ key: 'homepage_hero', value: heroPayload });
    const { error: heroErr } = await heroQ;
    if (heroErr) { toast('首页文字保存失败：' + heroErr.message, true); return; }

    toast('设置已保存'); closeModal();
  });
}

// ============================================================================
// 订单管理
// ============================================================================
async function renderOrdersPanel() {
  const content = document.getElementById('panelContent');
  content.innerHTML = `
    <div class="flex flex-wrap gap-2 mb-4">
      <select id="statusFilter" class="border rounded-lg px-3 py-2 text-sm bg-white">
        <option value="">全部状态</option>
        <option value="pending">🟡 待审核</option>
        <option value="quoted">🟠 已报价待定金</option>
        <option value="deposit_confirmed">🟢 定金核验到账排班</option>
        <option value="in_service">🔵 服务中</option>
        <option value="completed">✅ 完成</option>
        <option value="cancelled">❌ 已取消</option>
      </select>
      <input id="searchInput" type="text" placeholder="搜索客户名 / WhatsApp / 订单号" class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-[180px]">
    </div>
    <div class="table-scroll">
      <table>
        <thead><tr>
          <th>订单号</th><th>客户</th><th>WhatsApp</th><th>服务类型</th><th>服务日期</th><th>时段</th>
          <th>宠物</th><th>状态</th><th>定金核验</th><th>操作</th>
        </tr></thead>
        <tbody id="ordersTbody"><tr><td colspan="10" class="text-center py-8">加载中…</td></tr></tbody>
      </table>
    </div>
  `;

  let allOrders = [];
  async function fetchOrders() {
    const { data, error } = await window.sb.from('orders').select('*').order('service_date', { ascending: true });
    if (error) { toast('加载订单失败：' + error.message, true); return; }
    allOrders = data || [];
    renderRows();
  }
  function renderRows() {
    const statusVal = document.getElementById('statusFilter').value;
    const q = document.getElementById('searchInput').value.trim().toLowerCase();
    let rows = allOrders;
    if (statusVal) rows = rows.filter(o => o.status === statusVal);
    if (q) rows = rows.filter(o => (o.customer_name || '').toLowerCase().includes(q) || (o.whatsapp || '').includes(q) || (o.order_number || '').toLowerCase().includes(q));
    const tbody = document.getElementById('ordersTbody');
    if (rows.length === 0) { tbody.innerHTML = '<tr><td colspan="10" class="text-center py-8 text-[var(--color-text-muted)]">暂无符合条件的订单</td></tr>'; return; }
    tbody.innerHTML = rows.map(o => `
      <tr class="${(o.has_bite_history || o.blacklist_flag) ? 'row-danger' : ''}">
        <td class="font-mono">${o.order_number}</td>
        <td>${escapeHtml(o.customer_name)}${o.blacklist_flag ? ' 🚫' : ''}</td>
        <td class="font-mono">${escapeHtml(o.whatsapp)}</td>
        <td>${SERVICE_TYPE_LABEL[o.service_type] || o.service_type}</td>
        <td>${fmtDate(o.service_date)}</td>
        <td>${escapeHtml(o.time_slot)}</td>
        <td>${SPECIES_LABEL[o.pet_species] || o.pet_species} × ${o.pet_count}${o.has_bite_history ? ' ⚠️咬人史' : ''}</td>
        <td>${statusBadgeHtml(o.status)}</td>
        <td>${o.deposit_verified ? '✅' : '⏳'}</td>
        <td><button class="btn-outline px-3 py-1.5 text-sm" data-id="${o.id}">查看/编辑</button></td>
      </tr>
    `).join('');
    tbody.querySelectorAll('button[data-id]').forEach(b => b.addEventListener('click', () => openOrderDetail(b.dataset.id, fetchOrders)));
  }

  document.getElementById('statusFilter').addEventListener('change', renderRows);
  document.getElementById('searchInput').addEventListener('input', renderRows);
  await fetchOrders();
}

async function openOrderDetail(orderId, onSaved) {
  const { data: o, error } = await window.sb.from('orders').select('*').eq('id', orderId).single();
  if (error) { toast('加载订单详情失败', true); return; }

  // 客户档案 + 黑名单检查
  let customer = null, pets = [], blacklistEntry = null, logs = [], proofs = [];
  if (o.customer_id) {
    const [{ data: c }, { data: p }] = await Promise.all([
      window.sb.from('customers').select('*').eq('id', o.customer_id).single(),
      window.sb.from('pets').select('*').eq('customer_id', o.customer_id)
    ]);
    customer = c; pets = p || [];
  }
  const { data: bl } = await window.sb.from('blacklist').select('*').eq('whatsapp', o.whatsapp).eq('is_active', true).limit(1);
  blacklistEntry = (bl && bl[0]) || null;
  const { data: lg } = await window.sb.from('order_logs').select('*').eq('order_id', orderId).order('created_at', { ascending: false });
  logs = lg || [];
  const { data: pf } = await window.sb.from('payment_proofs').select('*').eq('order_id', orderId).order('uploaded_at', { ascending: false });
  proofs = pf || [];

  const checklist = o.service_type === 'feeding_jb' ? o.feeding_checklist : o.transport_checklist;
  const checklistLabels = o.service_type === 'feeding_jb' ? FEEDING_CHECKLIST_LABELS : TRANSPORT_CHECKLIST_LABELS;

  const html = `
    ${blacklistEntry ? `
      <div class="chip-danger rounded-xl p-4 mb-4">
        <p class="font-bold">🚫 该客户在黑名单中，请评估是否接单</p>
        <p class="text-sm mt-1">拉黑原因：${escapeHtml(blacklistEntry.reason)}</p>
        ${blacklistEntry.notes ? `<p class="text-sm">备注：${escapeHtml(blacklistEntry.notes)}</p>` : ''}
      </div>` : ''}
    ${o.has_bite_history ? `
      <div class="chip-danger rounded-xl p-4 mb-4">
        <p class="font-bold">⚠️ 该宠物有咬人/攻击记录</p>
        <p class="text-sm mt-1">${escapeHtml(o.bite_notes || '（未填写备注）')}</p>
      </div>` : ''}

    <div class="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm mb-5">
      <div><p class="text-[var(--color-text-muted)]">订单号</p><p class="font-mono font-bold">${o.order_number}</p></div>
      <div><p class="text-[var(--color-text-muted)]">服务类型</p><p class="font-semibold">${SERVICE_TYPE_LABEL[o.service_type]}</p></div>
      <div><p class="text-[var(--color-text-muted)]">服务日期</p><p class="font-semibold">${fmtDate(o.service_date)} ${escapeHtml(o.time_slot)}</p></div>
      ${o.service_type === 'transport_west' ? `<div><p class="text-[var(--color-text-muted)]">长途占用天数</p><p class="font-semibold">${o.long_trip_days} 天</p></div>` : ''}
      ${o.service_type === 'feeding_jb' ? `<div><p class="text-[var(--color-text-muted)]">喂养天数</p><p class="font-semibold">${o.feeding_days || 1} 天</p></div>` : ''}
      <div><p class="text-[var(--color-text-muted)]">客户</p><p class="font-semibold">${escapeHtml(o.customer_name)}</p></div>
      <div><p class="text-[var(--color-text-muted)]">WhatsApp</p><p class="font-mono font-semibold">${escapeHtml(o.whatsapp)}</p></div>
      <div><p class="text-[var(--color-text-muted)]">宠物</p><p class="font-semibold">${SPECIES_LABEL[o.pet_species]} × ${o.pet_count}（${escapeHtml(o.pet_size)}）</p></div>
      <div><p class="text-[var(--color-text-muted)]">地址</p><p class="font-semibold">${escapeHtml(o.address)}</p></div>
      ${o.service_type === 'feeding_jb' && o.extra_services && o.extra_services.length ? `<div><p class="text-[var(--color-text-muted)]">额外附加服务</p><p class="font-semibold">${o.extra_services.map(escapeHtml).join('、')}</p></div>` : ''}
      <div><p class="text-[var(--color-text-muted)]">病史/特殊需求</p><p class="font-semibold">${escapeHtml(o.medical_history)}</p></div>
      ${o.extra_notes ? `<div><p class="text-[var(--color-text-muted)]">额外注意事项</p><p class="font-semibold">${escapeHtml(o.extra_notes)}</p></div>` : ''}
      <div><p class="text-[var(--color-text-muted)]">紧急联系人</p><p class="font-semibold">${escapeHtml(o.emergency_contact_name)} ${escapeHtml(o.emergency_contact_phone)}</p></div>
      <div><p class="text-[var(--color-text-muted)]">兽医联系方式</p><p class="font-semibold">${escapeHtml(o.vet_contact)}</p></div>
      <div><p class="text-[var(--color-text-muted)]">钥匙交接方式</p><p class="font-semibold">${escapeHtml(o.key_handover_method)}</p></div>
      <div><p class="text-[var(--color-text-muted)]">拍照录像取证</p><p class="font-semibold">${o.consent_photo_video ? '同意' : '不同意'}</p></div>
    </div>

    ${customer ? `
      <div class="card p-4 mb-5">
        <p class="font-semibold mb-2">📇 客户档案（自动带出，减少重复询问）</p>
        <p class="text-sm text-[var(--color-text-muted)] mb-2">${escapeHtml(customer.notes || '暂无历史服务备注')}</p>
        ${pets.length ? pets.map(p => `
          <div class="text-sm border-t border-dashed border-[#E4E1D8] pt-2 mt-2">
            <p class="font-semibold">${escapeHtml(p.name || '未命名宠物')}（${SPECIES_LABEL[p.species] || ''}）</p>
            <p class="text-[var(--color-text-muted)]">性格：${escapeHtml(p.personality || '-')}　饮食：${escapeHtml(p.diet || '-')}</p>
            <p class="text-[var(--color-text-muted)]">喜好：${escapeHtml(p.likes || '-')}　害怕：${escapeHtml(p.fears || '-')}</p>
            <p class="text-[var(--color-text-muted)]">禁忌：${escapeHtml(p.taboos || '-')}　长期注意：${escapeHtml(p.long_term_notes || '-')}</p>
          </div>
        `).join('') : '<p class="text-sm text-[var(--color-text-muted)]">暂无宠物档案记录，可到「客户档案库」补充</p>'}
      </div>` : ''}

    <div class="card p-4 mb-5 space-y-3">
      <p class="font-semibold">💵 报价与订单状态</p>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="text-xs text-[var(--color-text-muted)]">订单状态</label>
          <select id="fStatus" class="w-full border rounded-lg px-3 py-2 bg-white">
            ${Object.keys(STATUS_LABELS).map(k => `<option value="${k}" ${o.status===k?'selected':''}>${STATUS_LABELS[k].emoji} ${STATUS_LABELS[k].text}</option>`).join('')}
          </select>
        </div>
        <div><label class="text-xs text-[var(--color-text-muted)]">总服务费 RM</label><input id="fTotal" type="number" step="0.01" value="${o.total_fee ?? ''}" class="w-full border rounded-lg px-3 py-2"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">路费附加费 RM</label><input id="fTransport" type="number" step="0.01" value="${o.transport_fee ?? ''}" class="w-full border rounded-lg px-3 py-2"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">定金金额 RM</label><input id="fDeposit" type="number" step="0.01" value="${o.deposit_amount ?? ''}" class="w-full border rounded-lg px-3 py-2"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">定金收款日期</label><input id="fDepositDate" type="date" value="${o.deposit_paid_date || ''}" class="w-full border rounded-lg px-3 py-2"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">全款收款日期</label><input id="fFullDate" type="date" value="${o.full_paid_date || ''}" class="w-full border rounded-lg px-3 py-2"></div>
      </div>
      <div class="flex flex-wrap gap-4 pt-1">
        <label class="inline-flex items-center gap-2 text-sm"><input id="fDepositVerified" type="checkbox" ${o.deposit_verified?'checked':''}> 定金核验到账（勾选后自动锁定排班）</label>
        <label class="inline-flex items-center gap-2 text-sm"><input id="fFullVerified" type="checkbox" ${o.full_payment_verified?'checked':''}> 尾款核验到账</label>
      </div>
      <button id="genIncomeBtn" class="btn-outline text-sm px-3 py-1.5">一键生成收入流水（总服务费）</button>
    </div>

    <div class="card p-4 mb-5 space-y-2">
      <p class="font-semibold">📝 内部备注</p>
      <textarea id="fInternalNotes" class="w-full border rounded-lg px-3 py-2" placeholder="堵车15-20分钟缓冲提醒、钥匙押金等">${escapeHtml(o.internal_notes || '')}</textarea>
    </div>

    <div class="card p-4 mb-5 space-y-3">
      <p class="font-semibold">❌ 取消处理</p>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="text-xs text-[var(--color-text-muted)]">取消方</label>
          <select id="fCancelBy" class="w-full border rounded-lg px-3 py-2 bg-white">
            <option value="">未取消</option>
            <option value="customer" ${o.cancel_by==='customer'?'selected':''}>客户取消</option>
            <option value="merchant" ${o.cancel_by==='merchant'?'selected':''}>商家取消</option>
          </select>
        </div>
        <div><label class="text-xs text-[var(--color-text-muted)]">定金处置</label>
          <select id="fCancelAction" class="w-full border rounded-lg px-3 py-2 bg-white">
            <option value="">-</option>
            <option value="refund" ${o.cancel_deposit_action==='refund'?'selected':''}>退款</option>
            <option value="reschedule" ${o.cancel_deposit_action==='reschedule'?'selected':''}>改期</option>
            <option value="forfeit" ${o.cancel_deposit_action==='forfeit'?'selected':''}>不予退还</option>
          </select>
        </div>
      </div>
      <p class="text-xs text-[var(--color-text-muted)]">选择「客户取消/商家取消」并将订单状态设为「已取消」保存后，如定金处置为「退款」将自动生成财务退款流水。</p>
    </div>

    <div class="card p-4 mb-5 space-y-2">
      <p class="font-semibold">✅ ${o.service_type === 'feeding_jb' ? '上门喂养' : '宠物接送'} Checklist</p>
      ${Object.keys(checklistLabels).map(k => `
        <label class="flex items-center gap-2 text-sm"><input type="checkbox" class="checklist-item" data-key="${k}" ${checklist[k] ? 'checked' : ''}> ${checklistLabels[k]}</label>
      `).join('')}
    </div>

    <div class="card p-4 mb-5">
      <p class="font-semibold mb-2">📎 客户上传凭证</p>
      ${proofs.length ? proofs.map(p => `
        <div class="flex items-center justify-between text-sm border-t border-dashed border-[#E4E1D8] py-2 first:border-t-0">
          <a href="${p.image_url}" target="_blank" class="underline">${p.proof_type === 'deposit' ? '定金凭证' : '尾款凭证'} · ${fmtDate(p.uploaded_at)}</a>
          ${p.verified ? '<span class="text-[var(--color-success)] text-xs font-semibold">✅ 已核验</span>' : `<button class="btn-outline text-xs px-2 py-1 verify-proof-btn" data-id="${p.id}">标记已核验</button>`}
        </div>
      `).join('') : '<p class="text-sm text-[var(--color-text-muted)]">暂无上传记录</p>'}
    </div>

    <div class="card p-4 mb-5">
      <p class="font-semibold mb-2">🕓 操作日志</p>
      ${logs.length ? `<ul class="text-sm space-y-1 max-h-40 overflow-y-auto">${logs.map(l => `<li>${fmtDateTime(l.created_at)} — ${escapeHtml(l.action)}</li>`).join('')}</ul>` : '<p class="text-sm text-[var(--color-text-muted)]">暂无记录</p>'}
    </div>

    <div class="flex gap-3">
      <button id="saveOrderBtn" class="btn-primary flex-1 py-3">保存修改</button>
      <button id="deleteOrderBtn" class="btn-outline text-red-600 px-4 py-3">🗑️ 删除订单</button>
    </div>
  `;

  openModal(html, { title: `订单详情 · ${o.order_number}`, wide: true });

  document.querySelectorAll('.verify-proof-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const { error } = await window.sb.from('payment_proofs').update({ verified: true, verified_at: new Date().toISOString() }).eq('id', btn.dataset.id);
      if (error) { toast('操作失败', true); return; }
      toast('已标记核验'); openOrderDetail(orderId, onSaved);
    });
  });

  document.getElementById('genIncomeBtn').addEventListener('click', async () => {
    const amount = parseFloat(document.getElementById('fTotal').value);
    if (!amount) { toast('请先填写总服务费', true); return; }
    const { error } = await window.sb.from('finance_transactions').insert({
      type: 'income', category: '订单收款', amount, order_id: orderId, customer_name: o.customer_name, notes: `订单 ${o.order_number} 收款`
    });
    if (error) { toast('生成失败：' + error.message, true); return; }
    toast('收入流水已生成');
  });

  document.getElementById('deleteOrderBtn').addEventListener('click', async () => {
    if (!confirm(`确认删除订单 ${o.order_number}？此操作不可撤销，客户以后无法再用此订单号查询。`)) return;
    if (!confirm('再次确认：真的要永久删除这笔订单吗？')) return;
    const { error } = await window.sb.from('orders').delete().eq('id', orderId);
    if (error) { toast('删除失败：' + error.message, true); return; }
    toast('订单已删除');
    closeModal();
    if (onSaved) onSaved();
  });

  document.getElementById('saveOrderBtn').addEventListener('click', async () => {
    const newStatus = document.getElementById('fStatus').value;
    const cancelBy = document.getElementById('fCancelBy').value || null;
    const cancelAction = document.getElementById('fCancelAction').value || null;
    const newDepositVerified = document.getElementById('fDepositVerified').checked;

    // 排班冲突检测（仅在新勾选定金核验时提示）
    if (newDepositVerified && !o.deposit_verified) {
      const scheduleDays = o.service_type === 'feeding_jb' ? (o.feeding_days || 1) : (o.long_trip_days || 1);
      const { data: conflict } = await window.sb.rpc('admin_check_schedule_conflict', {
        p_start: o.service_date, p_days: scheduleDays, p_exclude_order_id: o.id
      });
      if (conflict && conflict.has_conflict) {
        const proceed = confirm('⚠️ 该时段与其他已锁定排班存在冲突，是否仍要继续锁定档期？');
        if (!proceed) return;
      }
    }

    const updatedChecklist = { ...checklist };
    document.querySelectorAll('.checklist-item').forEach(cb => { updatedChecklist[cb.dataset.key] = cb.checked; });

    const payload = {
      status: newStatus,
      total_fee: document.getElementById('fTotal').value === '' ? null : parseFloat(document.getElementById('fTotal').value),
      transport_fee: document.getElementById('fTransport').value === '' ? null : parseFloat(document.getElementById('fTransport').value),
      deposit_amount: document.getElementById('fDeposit').value === '' ? null : parseFloat(document.getElementById('fDeposit').value),
      deposit_paid_date: document.getElementById('fDepositDate').value || null,
      full_paid_date: document.getElementById('fFullDate').value || null,
      deposit_verified: newDepositVerified,
      full_payment_verified: document.getElementById('fFullVerified').checked,
      internal_notes: document.getElementById('fInternalNotes').value || null,
      cancel_by: newStatus === 'cancelled' ? cancelBy : null,
      cancel_deposit_action: newStatus === 'cancelled' ? cancelAction : null,
      cancelled_at: newStatus === 'cancelled' ? new Date().toISOString() : null,
    };
    if (o.service_type === 'feeding_jb') payload.feeding_checklist = updatedChecklist;
    else payload.transport_checklist = updatedChecklist;

    const { error } = await window.sb.from('orders').update(payload).eq('id', orderId);
    if (error) { toast('保存失败：' + error.message, true); return; }
    toast('已保存'); closeModal();
    if (onSaved) onSaved();
  });
}

function fmtDateTime(d) {
  if (!d) return '-';
  try { return new Date(d).toLocaleString('zh-CN', { year:'numeric', month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit' }); } catch (e) { return d; }
}

// ============================================================================
// 排班日历（日/周视图切换）
// ============================================================================
let calendarView = 'week';
let calendarDate = new Date();

async function renderCalendarPanel() {
  const content = document.getElementById('panelContent');
  content.innerHTML = `
    <div class="flex items-center gap-2 mb-4 flex-wrap">
      <div class="flex rounded-lg overflow-hidden border">
        <button id="viewDayBtn" class="px-3 py-1.5 text-sm ${calendarView==='day'?'bg-[var(--color-primary)] text-white':'bg-white'}">日视图</button>
        <button id="viewWeekBtn" class="px-3 py-1.5 text-sm ${calendarView==='week'?'bg-[var(--color-primary)] text-white':'bg-white'}">周视图</button>
      </div>
      <button id="prevBtn" class="btn-outline px-3 py-1.5 text-sm">‹ 上一${calendarView==='day'?'天':'周'}</button>
      <button id="todayBtn" class="btn-outline px-3 py-1.5 text-sm">今天</button>
      <button id="nextBtn" class="btn-outline px-3 py-1.5 text-sm">下一${calendarView==='day'?'天':'周'} ›</button>
      <span id="rangeLabel" class="font-semibold ml-1"></span>
    </div>
    <div id="calendarBody"></div>
  `;
  document.getElementById('viewDayBtn').addEventListener('click', () => { calendarView = 'day'; renderCalendarPanel(); });
  document.getElementById('viewWeekBtn').addEventListener('click', () => { calendarView = 'week'; renderCalendarPanel(); });
  document.getElementById('prevBtn').addEventListener('click', () => { shiftDate(-1); renderCalendarPanel(); });
  document.getElementById('nextBtn').addEventListener('click', () => { shiftDate(1); renderCalendarPanel(); });
  document.getElementById('todayBtn').addEventListener('click', () => { calendarDate = new Date(); renderCalendarPanel(); });

  if (calendarView === 'day') await renderDayView(); else await renderWeekView();
}
function shiftDate(dir) {
  const d = new Date(calendarDate);
  d.setDate(d.getDate() + (calendarView === 'day' ? dir : dir * 7));
  calendarDate = d;
}
function isoDate(d) { return d.toISOString().slice(0, 10); }
function startOfWeek(d) { const r = new Date(d); const day = r.getDay(); r.setDate(r.getDate() - day); return r; }

// 计算一笔订单实际占用的天数：喂养订单用喂养天数，接送订单用长途天数
function orderSpanDays(o) {
  return o.service_type === 'feeding_jb' ? (o.feeding_days || 1) : (o.long_trip_days || 1);
}
function addDaysStr(dateStr, days) {
  const d = new Date(dateStr + 'T00:00:00');
  d.setDate(d.getDate() + days);
  return isoDate(d);
}

async function renderDayView() {
  const dateStr = isoDate(calendarDate);
  document.getElementById('rangeLabel').textContent = fmtDate(dateStr);
  // 多天订单（喂养多日/长途接送）可能是更早的日期提交的，往前多拉 30 天范围以覆盖跨天占用
  const rangeStart = addDaysStr(dateStr, -30);
  const { data: candidates } = await window.sb.from('orders').select('*')
    .gte('service_date', rangeStart).lte('service_date', dateStr).order('time_slot');
  const orders = (candidates || []).filter(o => {
    const span = orderSpanDays(o);
    return dateStr >= o.service_date && dateStr <= addDaysStr(o.service_date, span - 1);
  });
  const body = document.getElementById('calendarBody');
  if (!orders || orders.length === 0) { body.innerHTML = '<p class="text-center text-[var(--color-text-muted)] py-10">当日暂无预约</p>'; return; }
  body.innerHTML = `<div class="space-y-3">${orders.map(o => dayCardHtml(o, dateStr)).join('')}</div>`;
  bindDayCardClicks(body);
}

async function renderWeekView() {
  const start = startOfWeek(calendarDate);
  const days = [...Array(7)].map((_, i) => { const d = new Date(start); d.setDate(d.getDate() + i); return d; });
  document.getElementById('rangeLabel').textContent = `${fmtDate(isoDate(days[0]))} — ${fmtDate(isoDate(days[6]))}`;
  const rangeStart = addDaysStr(isoDate(days[0]), -30);
  const { data: candidates } = await window.sb.from('orders').select('*')
    .gte('service_date', rangeStart).lte('service_date', isoDate(days[6]));
  const byDate = {};
  (candidates || []).forEach(o => {
    const span = orderSpanDays(o);
    for (let i = 0; i < span; i++) {
      const d = addDaysStr(o.service_date, i);
      if (d >= isoDate(days[0]) && d <= isoDate(days[6])) {
        (byDate[d] = byDate[d] || []).push(o);
      }
    }
  });

  const body = document.getElementById('calendarBody');
  body.innerHTML = `
    <div class="grid grid-cols-7 gap-2">
      ${days.map(d => {
        const key = isoDate(d);
        const list = byDate[key] || [];
        const hasRisk = list.some(o => o.has_bite_history || o.blacklist_flag);
        return `
        <button class="day-cell card p-2 text-left flex flex-col gap-1 ${hasRisk ? 'ring-2 ring-red-400' : ''}" data-date="${key}">
          <span class="text-xs text-[var(--color-text-muted)]">${['周日','周一','周二','周三','周四','周五','周六'][d.getDay()]}</span>
          <span class="font-semibold text-sm">${d.getDate()}日</span>
          ${list.length ? `<span class="badge badge-deposit self-start mt-1">${list.length} 单</span>` : ''}
        </button>`;
      }).join('')}
    </div>
    <div id="weekDayDetail" class="mt-4"></div>
  `;
  body.querySelectorAll('.day-cell').forEach(btn => {
    btn.addEventListener('click', () => {
      calendarDate = new Date(btn.dataset.date + 'T00:00:00');
      calendarView = 'day';
      renderCalendarPanel();
    });
  });
}

function dayCardHtml(o, dateStr) {
  const risk = o.has_bite_history || o.blacklist_flag;
  const span = orderSpanDays(o);
  const dayIndex = dateStr ? (Math.round((new Date(dateStr) - new Date(o.service_date)) / 86400000) + 1) : 1;
  return `
    <div class="card p-3 md:p-4 ${risk ? 'ring-2 ring-red-400' : ''} cursor-pointer calendar-order-card" data-id="${o.id}">
      <div class="flex justify-between items-start">
        <div>
          <p class="font-semibold">${escapeHtml(o.customer_name)} ${risk ? '⚠️' : ''}</p>
          <p class="text-sm text-[var(--color-text-muted)]">${escapeHtml(o.time_slot)} · ${SERVICE_TYPE_LABEL[o.service_type]} · ${SPECIES_LABEL[o.pet_species]}×${o.pet_count}</p>
          ${span > 1 ? `<p class="text-xs mt-0.5 text-[var(--color-primary)]">📅 连续 ${span} 天服务的第 ${dayIndex} 天（${fmtDate(o.service_date)} 起）</p>` : ''}
        </div>
        ${statusBadgeHtml(o.status)}
      </div>
      ${o.internal_notes ? `<p class="text-xs mt-2 text-[var(--color-text-muted)]">📝 ${escapeHtml(o.internal_notes)}</p>` : ''}
    </div>
  `;
}
function bindDayCardClicks(container) {
  container.querySelectorAll('.calendar-order-card').forEach(c => {
    c.addEventListener('click', () => openOrderDetail(c.dataset.id, () => loadPanel('calendar')));
  });
}

// ============================================================================
// 客户档案库
// ============================================================================
async function renderCustomersPanel() {
  const content = document.getElementById('panelContent');
  content.innerHTML = `
    <input id="customerSearch" type="text" placeholder="搜索姓名 / WhatsApp" class="border rounded-lg px-3 py-2 text-sm w-full max-w-sm mb-4">
    <div class="table-scroll">
      <table>
        <thead><tr><th>姓名</th><th>WhatsApp</th><th>建档时间</th><th>操作</th></tr></thead>
        <tbody id="customersTbody"><tr><td colspan="4" class="text-center py-8">加载中…</td></tr></tbody>
      </table>
    </div>
  `;
  let all = [];
  async function fetchAll() {
    const { data, error } = await window.sb.from('customers').select('*').order('created_at', { ascending: false });
    if (error) { toast('加载失败', true); return; }
    all = data || []; renderRows();
  }
  function renderRows() {
    const q = document.getElementById('customerSearch').value.trim().toLowerCase();
    const rows = q ? all.filter(c => (c.full_name||'').toLowerCase().includes(q) || (c.whatsapp||'').includes(q)) : all;
    document.getElementById('customersTbody').innerHTML = rows.length ? rows.map(c => `
      <tr>
        <td>${escapeHtml(c.full_name)}</td>
        <td class="font-mono">${escapeHtml(c.whatsapp)}</td>
        <td>${fmtDate(c.created_at)}</td>
        <td><button class="btn-outline px-3 py-1.5 text-sm" data-id="${c.id}">查看/编辑</button></td>
      </tr>
    `).join('') : '<tr><td colspan="4" class="text-center py-8 text-[var(--color-text-muted)]">暂无客户记录</td></tr>';
    document.querySelectorAll('#customersTbody button[data-id]').forEach(b => b.addEventListener('click', () => openCustomerDetail(b.dataset.id, fetchAll)));
  }
  document.getElementById('customerSearch').addEventListener('input', renderRows);
  await fetchAll();
}

async function openCustomerDetail(customerId, onSaved) {
  const [{ data: c }, { data: pets }, { data: orders }] = await Promise.all([
    window.sb.from('customers').select('*').eq('id', customerId).single(),
    window.sb.from('pets').select('*').eq('customer_id', customerId).order('created_at'),
    window.sb.from('orders').select('order_number, service_date, status').eq('customer_id', customerId).order('service_date', { ascending: false })
  ]);

  const html = `
    <div class="space-y-3 mb-6">
      <div><label class="text-xs text-[var(--color-text-muted)]">客户全名</label><input id="custName" class="w-full border rounded-lg px-3 py-2" value="${escapeHtml(c.full_name)}"></div>
      <div><label class="text-xs text-[var(--color-text-muted)]">WhatsApp</label><input class="w-full border rounded-lg px-3 py-2 bg-gray-100 font-mono" value="${escapeHtml(c.whatsapp)}" disabled></div>
      <div><label class="text-xs text-[var(--color-text-muted)]">历史服务备注</label><textarea id="custNotes" class="w-full border rounded-lg px-3 py-2">${escapeHtml(c.notes || '')}</textarea></div>
      <button id="saveCustomerBtn" class="btn-primary px-4 py-2 text-sm">保存客户资料</button>
    </div>

    <div class="mb-6">
      <p class="font-semibold mb-2">🐾 宠物档案</p>
      <div id="petsList" class="space-y-3">${(pets||[]).map(petFormHtml).join('') || '<p class="text-sm text-[var(--color-text-muted)]">暂无宠物档案</p>'}</div>
      <button id="addPetBtn" class="btn-outline text-sm px-3 py-1.5 mt-2">+ 新增宠物档案</button>
    </div>

    <div>
      <p class="font-semibold mb-2">📜 历史订单</p>
      ${(orders||[]).length ? `<ul class="text-sm space-y-1">${orders.map(o => `<li class="flex justify-between border-b border-dashed border-[#E4E1D8] py-1"><span class="font-mono">${o.order_number}</span><span>${fmtDate(o.service_date)}</span>${statusBadgeHtml(o.status)}</li>`).join('')}</ul>` : '<p class="text-sm text-[var(--color-text-muted)]">暂无历史订单</p>'}
    </div>
  `;
  openModal(html, { title: `客户档案 · ${c.full_name}`, wide: true });

  document.getElementById('saveCustomerBtn').addEventListener('click', async () => {
    const { error } = await window.sb.from('customers').update({
      full_name: document.getElementById('custName').value.trim(),
      notes: document.getElementById('custNotes').value
    }).eq('id', customerId);
    if (error) { toast('保存失败', true); return; }
    toast('已保存'); if (onSaved) onSaved();
  });

  document.getElementById('addPetBtn').addEventListener('click', () => {
    const div = document.createElement('div');
    div.innerHTML = petFormHtml({ id: '', customer_id: customerId });
    document.getElementById('petsList').appendChild(div.firstElementChild);
    bindPetForms();
  });
  bindPetForms();

  function bindPetForms() {
    document.querySelectorAll('.save-pet-btn').forEach(btn => {
      btn.onclick = async () => {
        const wrap = btn.closest('.pet-form');
        const payload = {
          customer_id: customerId,
          name: wrap.querySelector('.p-name').value.trim(),
          species: wrap.querySelector('.p-species').value,
          personality: wrap.querySelector('.p-personality').value,
          diet: wrap.querySelector('.p-diet').value,
          likes: wrap.querySelector('.p-likes').value,
          fears: wrap.querySelector('.p-fears').value,
          taboos: wrap.querySelector('.p-taboos').value,
          long_term_notes: wrap.querySelector('.p-notes').value
        };
        const petId = wrap.dataset.id;
        const q = petId ? window.sb.from('pets').update(payload).eq('id', petId) : window.sb.from('pets').insert(payload);
        const { error } = await q;
        if (error) { toast('保存失败：' + error.message, true); return; }
        toast('宠物档案已保存'); openCustomerDetail(customerId, onSaved);
      };
    });
  }
}
function petFormHtml(p) {
  return `
    <div class="pet-form card p-3 space-y-2" data-id="${p.id || ''}">
      <div class="grid grid-cols-2 gap-2">
        <input class="p-name border rounded-lg px-2 py-1.5 text-sm" placeholder="宠物名称" value="${escapeHtml(p.name || '')}">
        <select class="p-species border rounded-lg px-2 py-1.5 text-sm bg-white">
          <option value="cat" ${p.species==='cat'?'selected':''}>猫</option>
          <option value="dog" ${p.species==='dog'?'selected':''}>狗</option>
        </select>
      </div>
      <input class="p-personality border rounded-lg px-2 py-1.5 text-sm w-full" placeholder="性格特点" value="${escapeHtml(p.personality || '')}">
      <input class="p-diet border rounded-lg px-2 py-1.5 text-sm w-full" placeholder="饮食习惯" value="${escapeHtml(p.diet || '')}">
      <input class="p-likes border rounded-lg px-2 py-1.5 text-sm w-full" placeholder="喜好" value="${escapeHtml(p.likes || '')}">
      <input class="p-fears border rounded-lg px-2 py-1.5 text-sm w-full" placeholder="害怕事物" value="${escapeHtml(p.fears || '')}">
      <input class="p-taboos border rounded-lg px-2 py-1.5 text-sm w-full" placeholder="禁忌事项" value="${escapeHtml(p.taboos || '')}">
      <textarea class="p-notes border rounded-lg px-2 py-1.5 text-sm w-full" placeholder="长期注意事项">${escapeHtml(p.long_term_notes || '')}</textarea>
      <button class="save-pet-btn btn-outline text-xs px-3 py-1.5">保存该宠物</button>
    </div>
  `;
}

// ============================================================================
// 黑名单管理
// ============================================================================
async function renderBlacklistPanel() {
  const content = document.getElementById('panelContent');
  content.innerHTML = `
    <button id="addBlacklistBtn" class="btn-primary px-4 py-2 text-sm mb-4">+ 新增黑名单</button>
    <div class="table-scroll">
      <table>
        <thead><tr><th>WhatsApp</th><th>客户名称</th><th>拉黑原因</th><th>备注</th><th>拉黑日期</th><th>状态</th><th>操作</th></tr></thead>
        <tbody id="blacklistTbody"><tr><td colspan="7" class="text-center py-8">加载中…</td></tr></tbody>
      </table>
    </div>
  `;
  async function fetchAll() {
    const { data, error } = await window.sb.from('blacklist').select('*').order('created_at', { ascending: false });
    if (error) { toast('加载失败', true); return; }
    document.getElementById('blacklistTbody').innerHTML = (data && data.length) ? data.map(b => `
      <tr>
        <td class="font-mono">${escapeHtml(b.whatsapp)}</td>
        <td>${escapeHtml(b.customer_name || '-')}</td>
        <td>${escapeHtml(b.reason)}</td>
        <td>${escapeHtml(b.notes || '-')}</td>
        <td>${fmtDate(b.blacklisted_date)}</td>
        <td>${b.is_active ? '<span class="badge chip-danger">🚫 生效中</span>' : '<span class="badge badge-completed">已解除</span>'}</td>
        <td><button class="btn-outline px-3 py-1.5 text-sm toggle-bl-btn" data-id="${b.id}" data-active="${b.is_active}">${b.is_active ? '临时解除' : '重新启用'}</button></td>
      </tr>
    `).join('') : '<tr><td colspan="7" class="text-center py-8 text-[var(--color-text-muted)]">暂无黑名单记录</td></tr>';
    document.querySelectorAll('.toggle-bl-btn').forEach(btn => btn.addEventListener('click', async () => {
      const { error } = await window.sb.from('blacklist').update({ is_active: btn.dataset.active !== 'true' }).eq('id', btn.dataset.id);
      if (error) { toast('操作失败', true); return; }
      fetchAll();
    }));
  }
  document.getElementById('addBlacklistBtn').addEventListener('click', () => {
    openModal(`
      <div class="space-y-3">
        <div><label class="text-xs text-[var(--color-text-muted)]">WhatsApp 号码</label><input id="blWhatsapp" class="w-full border rounded-lg px-3 py-2" placeholder="60123456789"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">客户名称</label><input id="blName" class="w-full border rounded-lg px-3 py-2"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">拉黑原因</label><textarea id="blReason" class="w-full border rounded-lg px-3 py-2"></textarea></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">备注</label><textarea id="blNotes" class="w-full border rounded-lg px-3 py-2"></textarea></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">拉黑日期</label><input id="blDate" type="date" value="${new Date().toISOString().slice(0,10)}" class="w-full border rounded-lg px-3 py-2"></div>
        <button id="saveBlBtn" class="btn-primary w-full py-2.5">保存</button>
      </div>
    `, { title: '新增黑名单' });
    document.getElementById('saveBlBtn').addEventListener('click', async () => {
      const payload = {
        whatsapp: document.getElementById('blWhatsapp').value.trim(),
        customer_name: document.getElementById('blName').value.trim(),
        reason: document.getElementById('blReason').value.trim(),
        notes: document.getElementById('blNotes').value.trim(),
        blacklisted_date: document.getElementById('blDate').value
      };
      if (!payload.whatsapp || !payload.reason) { toast('请填写 WhatsApp 号码与拉黑原因', true); return; }
      const { error } = await window.sb.from('blacklist').insert(payload);
      if (error) { toast('保存失败：' + error.message, true); return; }
      toast('已加入黑名单'); closeModal(); fetchAll();
    });
  });
  await fetchAll();
}

// ============================================================================
// 财务收支台账
// ============================================================================
async function renderFinancePanel() {
  const content = document.getElementById('panelContent');
  const now = new Date();
  content.innerHTML = `
    <div class="grid grid-cols-3 gap-3 mb-5">
      <div class="card p-4"><p class="text-xs text-[var(--color-text-muted)]">本月总收入</p><p id="sumIncome" class="font-mono font-bold text-lg text-[var(--color-success)]">-</p></div>
      <div class="card p-4"><p class="text-xs text-[var(--color-text-muted)]">本月总支出</p><p id="sumExpense" class="font-mono font-bold text-lg text-[var(--color-danger)]">-</p></div>
      <div class="card p-4"><p class="text-xs text-[var(--color-text-muted)]">本月净利润</p><p id="sumNet" class="font-mono font-bold text-lg">-</p></div>
    </div>
    <div class="flex flex-wrap gap-2 mb-4">
      <button id="addTxnBtn" class="btn-primary px-4 py-2 text-sm">+ 新增流水</button>
      <button id="exportBtn" class="btn-outline px-4 py-2 text-sm">导出 Excel</button>
      <select id="typeFilter" class="border rounded-lg px-3 py-2 text-sm bg-white ml-auto">
        <option value="">全部类型</option><option value="income">收入</option><option value="expense">支出</option><option value="refund">退款</option>
      </select>
    </div>
    <div class="table-scroll">
      <table>
        <thead><tr><th>日期</th><th>类型</th><th>分类</th><th>金额</th><th>关联订单</th><th>客户</th><th>备注</th></tr></thead>
        <tbody id="txnTbody"><tr><td colspan="7" class="text-center py-8">加载中…</td></tr></tbody>
      </table>
    </div>
  `;
  let all = [];
  const TYPE_LABEL = { income: '🟢 收入', expense: '🔴 支出', refund: '🟠 退款' };

  async function fetchAll() {
    const { data, error } = await window.sb.from('finance_transactions').select('*').order('txn_date', { ascending: false });
    if (error) { toast('加载失败', true); return; }
    all = data || [];
    computeSummary();
    renderRows();
  }
  function computeSummary() {
    const ym = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
    const monthTxns = all.filter(t => (t.txn_date || '').startsWith(ym));
    const income = monthTxns.filter(t=>t.type==='income').reduce((s,t)=>s+Number(t.amount),0);
    const expense = monthTxns.filter(t=>t.type==='expense').reduce((s,t)=>s+Number(t.amount),0);
    const refund = monthTxns.filter(t=>t.type==='refund').reduce((s,t)=>s+Number(t.amount),0);
    document.getElementById('sumIncome').textContent = fmtMoney(income);
    document.getElementById('sumExpense').textContent = fmtMoney(expense);
    document.getElementById('sumNet').textContent = fmtMoney(income - expense - refund);
  }
  function renderRows() {
    const t = document.getElementById('typeFilter').value;
    const rows = t ? all.filter(r => r.type === t) : all;
    document.getElementById('txnTbody').innerHTML = rows.length ? rows.map(r => `
      <tr>
        <td>${fmtDate(r.txn_date)}</td>
        <td>${TYPE_LABEL[r.type]}</td>
        <td>${escapeHtml(r.category)}</td>
        <td class="font-mono">${fmtMoney(r.amount)}</td>
        <td>${r.order_id ? '关联订单' : '-'}</td>
        <td>${escapeHtml(r.customer_name || '-')}</td>
        <td>${escapeHtml(r.notes || '-')}</td>
      </tr>
    `).join('') : '<tr><td colspan="7" class="text-center py-8 text-[var(--color-text-muted)]">暂无记录</td></tr>';
  }
  document.getElementById('typeFilter').addEventListener('change', renderRows);

  document.getElementById('addTxnBtn').addEventListener('click', () => {
    openModal(`
      <div class="space-y-3">
        <div><label class="text-xs text-[var(--color-text-muted)]">类型</label>
          <select id="txnType" class="w-full border rounded-lg px-3 py-2 bg-white">
            <option value="income">收入</option><option value="expense">支出</option>
          </select>
        </div>
        <div><label class="text-xs text-[var(--color-text-muted)]">分类</label><input id="txnCategory" class="w-full border rounded-lg px-3 py-2" placeholder="例如：饰品售卖 / 燃油费 / 耗材 / 进货 / 杂费"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">金额 RM</label><input id="txnAmount" type="number" step="0.01" class="w-full border rounded-lg px-3 py-2"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">日期</label><input id="txnDate" type="date" value="${new Date().toISOString().slice(0,10)}" class="w-full border rounded-lg px-3 py-2"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">客户名称（可选）</label><input id="txnCustomer" class="w-full border rounded-lg px-3 py-2"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">关联订单号（可选）</label><input id="txnOrderNumber" class="w-full border rounded-lg px-3 py-2" placeholder="留空则不关联"></div>
        <div><label class="text-xs text-[var(--color-text-muted)]">备注</label><textarea id="txnNotes" class="w-full border rounded-lg px-3 py-2"></textarea></div>
        <button id="saveTxnBtn" class="btn-primary w-full py-2.5">保存</button>
      </div>
    `, { title: '新增财务流水' });
    document.getElementById('saveTxnBtn').addEventListener('click', async () => {
      const amount = parseFloat(document.getElementById('txnAmount').value);
      if (!amount) { toast('请填写金额', true); return; }
      let orderId = null;
      const orderNumber = document.getElementById('txnOrderNumber').value.trim();
      if (orderNumber) {
        const { data: ord } = await window.sb.from('orders').select('id').eq('order_number', orderNumber.toUpperCase()).single();
        if (ord) orderId = ord.id; else { toast('未找到该订单号，将不关联订单', false); }
      }
      const payload = {
        type: document.getElementById('txnType').value,
        category: document.getElementById('txnCategory').value.trim() || '未分类',
        amount, txn_date: document.getElementById('txnDate').value,
        customer_name: document.getElementById('txnCustomer').value.trim() || null,
        order_id: orderId,
        notes: document.getElementById('txnNotes').value.trim() || null
      };
      const { error } = await window.sb.from('finance_transactions').insert(payload);
      if (error) { toast('保存失败：' + error.message, true); return; }
      toast('已保存'); closeModal(); fetchAll();
    });
  });

  document.getElementById('exportBtn').addEventListener('click', () => {
    const ws = XLSX.utils.json_to_sheet(all.map(r => ({
      日期: r.txn_date, 类型: TYPE_LABEL[r.type], 分类: r.category, 金额: r.amount,
      客户: r.customer_name || '', 备注: r.notes || ''
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, '财务台账');
    const ym = `${now.getFullYear()}${String(now.getMonth()+1).padStart(2,'0')}`;
    XLSX.writeFile(wb, `财务台账_${ym}.xlsx`);
  });

  await fetchAll();
}

// ============================================================================
// 商城商品管理
// ============================================================================
async function renderProductsPanel() {
  const content = document.getElementById('panelContent');
  content.innerHTML = `
    <button id="addProductBtn" class="btn-primary px-4 py-2 text-sm mb-4">+ 新增展品</button>
    <div class="table-scroll">
      <table>
        <thead><tr><th>图片</th><th>名称</th><th>售价</th><th>排序</th><th>状态</th><th>操作</th></tr></thead>
        <tbody id="productsTbody"><tr><td colspan="6" class="text-center py-8">加载中…</td></tr></tbody>
      </table>
    </div>
  `;
  async function fetchAll() {
    const { data, error } = await window.sb.from('products').select('*').order('sort_order');
    if (error) { toast('加载失败', true); return; }
    document.getElementById('productsTbody').innerHTML = (data && data.length) ? data.map(p => `
      <tr>
        <td><img src="${escapeHtml(p.image_url)}" class="w-12 h-12 object-cover rounded-lg" onerror="this.src='https://placehold.co/60x60?text=%F0%9F%90%BE'"></td>
        <td>${escapeHtml(p.name)}</td>
        <td class="font-mono">${fmtMoney(p.price)}</td>
        <td>${p.sort_order}</td>
        <td>${p.is_active ? '<span class="badge badge-deposit">上架中</span>' : '<span class="badge badge-cancelled">已下架</span>'}</td>
        <td class="flex gap-2">
          <button class="btn-outline px-3 py-1.5 text-sm edit-p-btn" data-id="${p.id}">编辑</button>
          <button class="btn-outline px-3 py-1.5 text-sm text-red-600 del-p-btn" data-id="${p.id}">删除</button>
        </td>
      </tr>
    `).join('') : '<tr><td colspan="6" class="text-center py-8 text-[var(--color-text-muted)]">暂无展品</td></tr>';
    document.querySelectorAll('.edit-p-btn').forEach(b => b.addEventListener('click', () => openProductForm(data.find(p=>p.id===b.dataset.id), fetchAll)));
    document.querySelectorAll('.del-p-btn').forEach(b => b.addEventListener('click', async () => {
      if (!confirm('确认删除该展品？')) return;
      const { error } = await window.sb.from('products').delete().eq('id', b.dataset.id);
      if (error) { toast('删除失败', true); return; }
      fetchAll();
    }));
  }
  document.getElementById('addProductBtn').addEventListener('click', () => openProductForm(null, fetchAll));
  await fetchAll();
}
function openProductForm(p, onSaved) {
  p = p || { image_url: '', name: '', name_en: '', name_ms: '', price: '', description: '', description_en: '', description_ms: '', is_active: true, sort_order: 0 };
  openModal(`
    <div class="space-y-3">
      ${imageUploadFieldHtml('pImage', p.image_url, '展品图片')}
      <div><label class="text-xs text-[var(--color-text-muted)]">商品名称</label><input id="pName" class="w-full border rounded-lg px-3 py-2" value="${escapeHtml(p.name)}"></div>
      <div><label class="text-xs text-[var(--color-text-muted)]">售价 RM</label><input id="pPrice" type="number" step="0.01" class="w-full border rounded-lg px-3 py-2" value="${p.price}"></div>
      <div><label class="text-xs text-[var(--color-text-muted)]">简短描述</label><textarea id="pDesc" class="w-full border rounded-lg px-3 py-2">${escapeHtml(p.description || '')}</textarea></div>
      <details>
        <summary class="text-xs text-[var(--color-primary)] cursor-pointer">🌐 多语言名称与描述（可选，不填则统一显示中文）</summary>
        <div class="space-y-3 mt-2">
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">English name</label>
            <input id="pNameEn" class="w-full border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(p.name_en || '')}">
            <textarea id="pDescEn" class="w-full border rounded-lg px-3 py-2 text-sm mt-1" placeholder="Short description in English">${escapeHtml(p.description_en || '')}</textarea>
          </div>
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">Nama Bahasa Melayu</label>
            <input id="pNameMs" class="w-full border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(p.name_ms || '')}">
            <textarea id="pDescMs" class="w-full border rounded-lg px-3 py-2 text-sm mt-1" placeholder="Penerangan ringkas dalam Bahasa Melayu">${escapeHtml(p.description_ms || '')}</textarea>
          </div>
        </div>
      </details>
      <div><label class="text-xs text-[var(--color-text-muted)]">排序（数字越小越靠前）</label><input id="pSort" type="number" class="w-full border rounded-lg px-3 py-2" value="${p.sort_order}"></div>
      <label class="inline-flex items-center gap-2 text-sm"><input id="pActive" type="checkbox" ${p.is_active?'checked':''}> 上架显示</label>
      <button id="savePBtn" class="btn-primary w-full py-2.5">保存</button>
    </div>
  `, { title: p.id ? '编辑展品' : '新增展品' });
  bindImageUploadField('pImage', 'products');
  document.getElementById('savePBtn').addEventListener('click', async () => {
    const payload = {
      image_url: document.getElementById('pImage').value.trim(),
      name: document.getElementById('pName').value.trim(),
      name_en: document.getElementById('pNameEn').value.trim() || null,
      name_ms: document.getElementById('pNameMs').value.trim() || null,
      price: parseFloat(document.getElementById('pPrice').value) || 0,
      description: document.getElementById('pDesc').value.trim(),
      description_en: document.getElementById('pDescEn').value.trim() || null,
      description_ms: document.getElementById('pDescMs').value.trim() || null,
      sort_order: parseInt(document.getElementById('pSort').value, 10) || 0,
      is_active: document.getElementById('pActive').checked
    };
    if (!payload.image_url || !payload.name) { toast('请填写图片链接与商品名称', true); return; }
    const q = p.id ? window.sb.from('products').update(payload).eq('id', p.id) : window.sb.from('products').insert(payload);
    const { error } = await q;
    if (error) { toast('保存失败：' + error.message, true); return; }
    toast('已保存'); closeModal(); onSaved();
  });
}

// ============================================================================
// 价目与条款管理
// ============================================================================
const PRICING_SYNTAX_HELP = `价格内容支持以下简易格式（每行一种）：
## 小节标题
### 更小一级说明
标签 | 数值        （例如：单猫单次 | RM30）
* 普通项目符号（服务包含项等）
- 小号灰色备注（例如：访客停车费由宠主承担）
空行用于分段，其余整行文字按普通段落显示`;

async function renderPricingPanel() {
  const content = document.getElementById('panelContent');
  content.innerHTML = `
    <div class="flex items-center justify-between mb-4">
      <h2 class="font-semibold">价目板块</h2>
      <button id="addPricingBtn" class="btn-primary px-4 py-2 text-sm">+ 新增价目板块</button>
    </div>
    <div id="pricingSectionsList" class="space-y-3 mb-8"><p class="text-center text-[var(--color-text-muted)] py-8">加载中…</p></div>

    <div class="card p-4 md:p-5 space-y-3">
      <h2 class="font-semibold">服务条款（预约页强制勾选内容）</h2>
      <p class="text-xs text-[var(--color-text-muted)]">每行一条条款，保存后预约页会自动按顺序编号显示。</p>
      <textarea id="termsTextarea" class="w-full border rounded-lg px-3 py-2 min-h-[220px]"></textarea>
      <details>
        <summary class="text-xs text-[var(--color-primary)] cursor-pointer">🌐 英文 / 马来文条款（可选，不填则统一显示中文）</summary>
        <div class="space-y-3 mt-2">
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">English terms（每行一条）</label>
            <textarea id="termsTextareaEn" class="w-full border rounded-lg px-3 py-2 min-h-[160px] text-sm"></textarea>
          </div>
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">Terma Bahasa Melayu（satu baris satu terma）</label>
            <textarea id="termsTextareaMs" class="w-full border rounded-lg px-3 py-2 min-h-[160px] text-sm"></textarea>
          </div>
        </div>
      </details>
      <button id="saveTermsBtn" class="btn-primary px-4 py-2 text-sm">保存服务条款</button>
    </div>
  `;

  async function fetchSections() {
    const { data, error } = await window.sb.from('pricing_sections').select('*').order('sort_order');
    if (error) { toast('加载价目失败：' + error.message, true); return; }
    const list = document.getElementById('pricingSectionsList');
    list.innerHTML = (data && data.length) ? data.map(sec => `
      <div class="card p-4 flex items-start gap-3">
        ${sec.image_url ? `<img src="${escapeHtml(sec.image_url)}" class="w-16 h-16 rounded-lg object-cover flex-shrink-0" onerror="this.style.display='none'">` : ''}
        <div class="flex-1 min-w-0">
          <div class="flex items-center gap-2 flex-wrap">
            <p class="font-semibold">${escapeHtml(sec.title)}</p>
            ${sec.subtitle ? `<span class="text-xs bg-[var(--color-primary-light)] px-2 py-0.5 rounded-full">${escapeHtml(sec.subtitle)}</span>` : ''}
            ${sec.service_key ? `<span class="text-xs bg-[var(--color-accent)] text-[#3A2705] px-2 py-0.5 rounded-full">🔗 ${sec.service_key === 'feeding_jb' ? '上门喂养' : '宠物接送'}独立页</span>` : ''}
            ${sec.is_active ? '<span class="badge badge-deposit">显示中</span>' : '<span class="badge badge-cancelled">已隐藏</span>'}
          </div>
          <p class="text-xs text-[var(--color-text-muted)] mt-1">排序：${sec.sort_order}</p>
        </div>
        <div class="flex flex-col gap-1.5 flex-shrink-0">
          <button class="btn-outline text-xs px-2.5 py-1 edit-sec-btn" data-id="${sec.id}">编辑</button>
          <button class="btn-outline text-xs px-2.5 py-1 text-red-600 del-sec-btn" data-id="${sec.id}">删除</button>
        </div>
      </div>
    `).join('') : '<p class="text-center text-[var(--color-text-muted)] py-8">暂无价目板块，点击右上角新增</p>';

    list.querySelectorAll('.edit-sec-btn').forEach(b => b.addEventListener('click', () => openPricingSectionForm(data.find(s => s.id === b.dataset.id), fetchSections)));
    list.querySelectorAll('.del-sec-btn').forEach(b => b.addEventListener('click', async () => {
      if (!confirm('确认删除该价目板块？此操作不可撤销。')) return;
      const { error } = await window.sb.from('pricing_sections').delete().eq('id', b.dataset.id);
      if (error) { toast('删除失败', true); return; }
      fetchSections();
    }));
  }
  document.getElementById('addPricingBtn').addEventListener('click', () => openPricingSectionForm(null, fetchSections));
  await fetchSections();

  // 服务条款
  const { data: termsRow } = await window.sb.from('system_settings').select('value').eq('key', 'service_terms').single();
  document.getElementById('termsTextarea').value = termsRow?.value?.body || '';
  document.getElementById('termsTextareaEn').value = termsRow?.value?.body_en || '';
  document.getElementById('termsTextareaMs').value = termsRow?.value?.body_ms || '';
  document.getElementById('saveTermsBtn').addEventListener('click', async () => {
    const body = document.getElementById('termsTextarea').value.trim();
    if (!body) { toast('条款内容不能为空', true); return; }
    const bodyEn = document.getElementById('termsTextareaEn').value.trim() || null;
    const bodyMs = document.getElementById('termsTextareaMs').value.trim() || null;
    const { data: existing } = await window.sb.from('system_settings').select('key').eq('key', 'service_terms').single();
    const q = existing
      ? window.sb.from('system_settings').update({ value: { body, body_en: bodyEn, body_ms: bodyMs } }).eq('key', 'service_terms')
      : window.sb.from('system_settings').insert({ key: 'service_terms', value: { body, body_en: bodyEn, body_ms: bodyMs } });
    const { error } = await q;
    if (error) { toast('保存失败：' + error.message, true); return; }
    toast('服务条款已保存');
  });
}

function openPricingSectionForm(sec, onSaved) {
  sec = sec || { title: '', subtitle: '', title_en: '', subtitle_en: '', body_en: '', title_ms: '', subtitle_ms: '', body_ms: '', image_url: '', body: '', is_active: true, sort_order: 0 };
  openModal(`
    <div class="space-y-3">
      <div><label class="text-xs text-[var(--color-text-muted)]">板块标题</label><input id="secTitle" class="w-full border rounded-lg px-3 py-2" value="${escapeHtml(sec.title)}" placeholder="例如：新山上门宠物喂养"></div>
      <div>
        <label class="text-xs text-[var(--color-text-muted)]">关联服务（用于首页服务卡片 & 独立介绍页）</label>
        <select id="secServiceKey" class="w-full border rounded-lg px-3 py-2 bg-white">
          <option value="" ${!sec.service_key ? 'selected' : ''}>不关联（仅作为价目补充说明，不会单独生成介绍页）</option>
          <option value="feeding_jb" ${sec.service_key === 'feeding_jb' ? 'selected' : ''}>上门喂养（新山）</option>
          <option value="transport_west" ${sec.service_key === 'transport_west' ? 'selected' : ''}>宠物接送（西马）</option>
        </select>
      </div>
      <div><label class="text-xs text-[var(--color-text-muted)]">标签（可选，显示在标题旁）</label><input id="secSubtitle" class="w-full border rounded-lg px-3 py-2" value="${escapeHtml(sec.subtitle || '')}" placeholder="例如：仅新山地区"></div>
      <details>
        <summary class="text-xs text-[var(--color-primary)] cursor-pointer">🌐 多语言标题与完整内容（可选，不填则统一显示中文）</summary>
        <div class="space-y-3 mt-2">
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">English title / tag</label>
            <input id="secTitleEn" class="w-full border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(sec.title_en || '')}" placeholder="e.g. Home Feeding in JB">
            <input id="secSubtitleEn" class="w-full border rounded-lg px-3 py-2 text-sm mt-1" value="${escapeHtml(sec.subtitle_en || '')}" placeholder="tag in English">
            <label class="text-xs text-[var(--color-text-muted)] mt-2 block">Full price content in English（用法跟中文一样：## 标题 / 标签 | 数值 / * 列表 / - 备注）</label>
            <textarea id="secBodyEn" class="w-full border rounded-lg px-3 py-2 text-sm mt-1 min-h-[140px] font-mono" placeholder="留空则该语言下显示中文完整内容">${escapeHtml(sec.body_en || '')}</textarea>
          </div>
          <div>
            <label class="text-xs text-[var(--color-text-muted)]">Tajuk / label Bahasa Melayu</label>
            <input id="secTitleMs" class="w-full border rounded-lg px-3 py-2 text-sm" value="${escapeHtml(sec.title_ms || '')}" placeholder="cth: Memberi Makan di JB">
            <input id="secSubtitleMs" class="w-full border rounded-lg px-3 py-2 text-sm mt-1" value="${escapeHtml(sec.subtitle_ms || '')}" placeholder="label dalam BM">
            <label class="text-xs text-[var(--color-text-muted)] mt-2 block">Kandungan harga penuh dalam Bahasa Melayu（format sama macam Cina：## tajuk / label | nilai / * senarai / - nota）</label>
            <textarea id="secBodyMs" class="w-full border rounded-lg px-3 py-2 text-sm mt-1 min-h-[140px] font-mono" placeholder="Biarkan kosong untuk paparkan kandungan Cina">${escapeHtml(sec.body_ms || '')}</textarea>
          </div>
        </div>
        <p class="text-xs text-[var(--color-text-muted)] mt-2">首页卡片摘要会自动从这里截取一小段，不用另外写简短说明；服务介绍页会显示完整内容。排版语法（## 标题、标签 | 数值、* 列表、- 备注）跟中文「价格内容」完全一样。</p>
      </details>
      ${imageUploadFieldHtml('secImage', sec.image_url, '板块配图（可选）')}
      <div>
        <label class="text-xs text-[var(--color-text-muted)]">价格内容</label>
        <textarea id="secBody" class="w-full border rounded-lg px-3 py-2 min-h-[240px] font-mono text-sm">${escapeHtml(sec.body || '')}</textarea>
        <details class="mt-1">
          <summary class="text-xs text-[var(--color-primary)] cursor-pointer">查看格式说明</summary>
          <pre class="text-xs bg-[var(--color-bg)] rounded-lg p-2 mt-1 whitespace-pre-wrap">${escapeHtml(PRICING_SYNTAX_HELP)}</pre>
        </details>
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="text-xs text-[var(--color-text-muted)]">排序（数字越小越靠前）</label><input id="secSort" type="number" class="w-full border rounded-lg px-3 py-2" value="${sec.sort_order}"></div>
        <label class="inline-flex items-center gap-2 text-sm mt-5"><input id="secActive" type="checkbox" ${sec.is_active ? 'checked' : ''}> 前台显示</label>
      </div>
      <button id="saveSecBtn" class="btn-primary w-full py-2.5">保存</button>
    </div>
  `, { title: sec.id ? '编辑价目板块' : '新增价目板块', wide: true });
  bindImageUploadField('secImage', 'pricing');

  document.getElementById('saveSecBtn').addEventListener('click', async () => {
    const payload = {
      title: document.getElementById('secTitle').value.trim(),
      subtitle: document.getElementById('secSubtitle').value.trim() || null,
      title_en: document.getElementById('secTitleEn').value.trim() || null,
      subtitle_en: document.getElementById('secSubtitleEn').value.trim() || null,
      body_en: document.getElementById('secBodyEn').value.trim() || null,
      title_ms: document.getElementById('secTitleMs').value.trim() || null,
      subtitle_ms: document.getElementById('secSubtitleMs').value.trim() || null,
      body_ms: document.getElementById('secBodyMs').value.trim() || null,
      image_url: document.getElementById('secImage').value.trim() || null,
      body: document.getElementById('secBody').value,
      service_key: document.getElementById('secServiceKey').value || null,
      sort_order: parseInt(document.getElementById('secSort').value, 10) || 0,
      is_active: document.getElementById('secActive').checked
    };
    if (!payload.title || !payload.body.trim()) { toast('请填写标题与价格内容', true); return; }
    const q = sec.id ? window.sb.from('pricing_sections').update(payload).eq('id', sec.id) : window.sb.from('pricing_sections').insert(payload);
    const { error } = await q;
    if (error) { toast('保存失败：' + error.message, true); return; }
    toast('已保存'); closeModal(); onSaved();
  });
}
