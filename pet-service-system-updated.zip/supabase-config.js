// ============================================================================
// Supabase 项目配置
// 部署前请将下方两个值替换为你自己 Supabase 项目的 URL 与 anon public key
// （Supabase 控制台 → Project Settings → API）
// 这两个值本身设计为公开值（anon key 只有匿名权限，业务安全依赖 RLS + 触发器），
// 可以安全地出现在前端静态文件中。
// ============================================================================
const SUPABASE_URL = "https://rryxrcymhpcexvtzqlun.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_xgarXf2503KQ0u-L5aek0g_PftbFWy2";

// 全局唯一客户端实例，所有页面共用
window.sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    storageKey: "js-pet-service-admin-auth"
  }
});

// 业务常量：与页面文案保持一致，修改价目/规则时同步这里的说明文字即可
window.BUSINESS_WHATSAPP = "60172012198"; // 替换为商家真实 WhatsApp 号码（含国家码，不带+或00）

function waLink(message) {
  const text = encodeURIComponent(message || "");
  return `https://wa.me/${window.BUSINESS_WHATSAPP}?text=${text}`;
}

function fmtMoney(n) {
  if (n === null || n === undefined || n === "") return "-";
  return "RM " + Number(n).toFixed(2);
}

function fmtDate(d) {
  if (!d) return "-";
  try {
    const dt = new Date(d);
    return dt.toLocaleDateString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit" });
  } catch (e) { return d; }
}

function copyToClipboard(text, onDone) {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => onDone && onDone(true)).catch(() => onDone && onDone(false));
  } else {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    try { document.execCommand("copy"); onDone && onDone(true); } catch (e) { onDone && onDone(false); }
    document.body.removeChild(ta);
  }
}

const STATUS_LABELS = {
  pending:            { emoji: "🟡", text: "待审核",       badge: "badge-pending" },
  quoted:             { emoji: "🟠", text: "已报价待定金", badge: "badge-quoted" },
  deposit_confirmed:  { emoji: "🟢", text: "定金核验到账排班", badge: "badge-deposit" },
  in_service:         { emoji: "🔵", text: "服务中",       badge: "badge-inservice" },
  completed:          { emoji: "✅", text: "完成",         badge: "badge-completed" },
  cancelled:          { emoji: "❌", text: "已取消",       badge: "badge-cancelled" }
};

const STATUS_I18N_KEY = {
  pending: 'statusPending', quoted: 'statusQuoted', deposit_confirmed: 'statusDepositConfirmed',
  in_service: 'statusInService', completed: 'statusCompleted', cancelled: 'statusCancelled'
};

function statusBadgeHtml(status) {
  const s = STATUS_LABELS[status] || { emoji: "", text: status, badge: "" };
  const text = (typeof t === 'function' && STATUS_I18N_KEY[status]) ? t(STATUS_I18N_KEY[status]) : s.text;
  return `<span class="badge ${s.badge}">${s.emoji} ${text}</span>`;
}
