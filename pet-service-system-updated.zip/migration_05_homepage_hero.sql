-- ============================================================================
-- migration_05_homepage_hero.sql
-- 新增「首页顶部大标题」可编辑设置（标题文字、说明文字、4个卖点标签、背景图片），
-- 后台「系统设置」里即可编辑，不用再改代码。
-- 仅新增内容，不影响现有数据，可在已上线项目上直接执行一次。
-- ============================================================================

insert into system_settings (key, value)
values ('homepage_hero', jsonb_build_object(
  'title', '毛孩子在家，也能被温柔照顾',
  'subtitle', '上门喂养减少寄养应激，让猫狗留在熟悉的家中安心生活；点对点宠物接送，专人专车安全送达。新山上门喂养・西马宠物接送，猫狗专属服务，让您安心出门、放心托付。',
  'features', jsonb_build_array('✅ 减少寄养应激', '🏠 上门看护更安心', '🚗 点对点专车接送', '📸 全程拍照留证'),
  'image_url', null
))
on conflict (key) do nothing;

-- 若之前执行过更早版本新增的 hero_banner（仅背景图）设置，把它的图片迁移过来后可以删除
update system_settings
set value = jsonb_set(value, '{image_url}', to_jsonb((select value->>'image_url' from system_settings where key = 'hero_banner')))
where key = 'homepage_hero'
  and (value->>'image_url') is null
  and exists (select 1 from system_settings where key = 'hero_banner' and value->>'image_url' is not null);

delete from system_settings where key = 'hero_banner';

-- ============================================================================
-- 完成。执行后到后台「系统设置」即可编辑首页大标题文字、说明文字、卖点标签与背景图片。
-- ============================================================================
