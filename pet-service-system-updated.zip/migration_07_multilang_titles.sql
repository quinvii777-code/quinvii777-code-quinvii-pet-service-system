-- ============================================================================
-- migration_07_multilang_titles.sql
-- 为 pricing_sections 新增英文/马来文标题与副标题字段，配合后台「价目与条款」
-- 的多语言输入框，让首页服务卡片和服务介绍页标题也能跟着切换语言。
-- （首页大标题的多语言文字存在 system_settings 的 homepage_hero 里，是 JSON
-- 字段，不需要改表结构，后台「系统设置」保存时会自动带上。）
-- 仅新增字段，不影响现有数据，可在已上线项目上直接执行一次。
-- ============================================================================

alter table pricing_sections add column if not exists title_en text;
alter table pricing_sections add column if not exists subtitle_en text;
alter table pricing_sections add column if not exists title_ms text;
alter table pricing_sections add column if not exists subtitle_ms text;

-- ============================================================================
-- 完成。执行后到后台「价目与条款」编辑板块，展开「多语言标题（可选）」即可填写
-- 英文/马来文标题，不填写时首页/服务页会自动显示中文标题。
-- ============================================================================
